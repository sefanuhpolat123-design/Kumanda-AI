package com.kumandaplus.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class TvProfile(val id: Long, val name: String, val brand: String, val channelList: List<Channel> = emptyList())
data class Channel(val name: String, val number: String, val aliases: String = "")

class TvStore(context: Context) {
    private val prefs = context.getSharedPreferences("kumanda_plus", Context.MODE_PRIVATE)
    fun all(): List<TvProfile> {
        val arr = JSONArray(prefs.getString("tvs", "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val ch = o.optJSONArray("channels") ?: JSONArray()
            TvProfile(o.getLong("id"), o.getString("name"), o.getString("brand"), (0 until ch.length()).map { j ->
                val c = ch.getJSONObject(j); Channel(c.getString("name"), c.getString("number"), c.optString("aliases"))
            })
        }
    }
    fun save(items: List<TvProfile>) {
        val arr = JSONArray()
        items.forEach { tv ->
            val channels = JSONArray(); tv.channelList.forEach { c -> channels.put(JSONObject().put("name", c.name).put("number", c.number).put("aliases", c.aliases)) }
            arr.put(JSONObject().put("id", tv.id).put("name", tv.name).put("brand", tv.brand).put("channels", channels))
        }
        prefs.edit().putString("tvs", arr.toString()).apply()
    }
    fun selected(): Long = prefs.getLong("selected_tv", -1L)
    fun select(id: Long) { prefs.edit().putLong("selected_tv", id).apply() }
    fun listening(): Boolean = prefs.getBoolean("listening", false)
    fun setListening(v: Boolean) { prefs.edit().putBoolean("listening", v).apply() }
}
