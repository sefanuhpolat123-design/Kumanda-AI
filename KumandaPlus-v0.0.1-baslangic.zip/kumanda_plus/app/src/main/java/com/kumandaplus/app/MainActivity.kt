package com.kumandaplus.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Teal = Color(0xFF087F73)
private val Ink = Color(0xFF172522)
private val Page = Color(0xFFF4F7F6)
val Brands = listOf("Toshiba", "Samsung", "LG", "Vestel", "Philips", "Sony", "TCL", "Hisense", "Arçelik", "Beko", "Grundig", "Regal", "Onvo", "Sunny", "Axen", "Telefunken", "Panasonic", "Sharp", "JVC", "Xiaomi", "Diğer")

class MainActivity : ComponentActivity() {
    private lateinit var store: TvStore
    private lateinit var ir: IrController
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = TvStore(this); ir = IrController(this)
        val required = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) required += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(required.toTypedArray())
        setContent { KumandaApp(store, ir, onStartVoice = { startVoice() }, onStopVoice = { stopService(Intent(this, VoiceListeningService::class.java)); store.setListening(false) }) }
    }
    private fun startVoice() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)); return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS)); return
        }
        ContextCompat.startForegroundService(this, Intent(this, VoiceListeningService::class.java)); store.setListening(true)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KumandaApp(store: TvStore, ir: IrController, onStartVoice: () -> Unit, onStopVoice: () -> Unit) {
    var tvs by remember { mutableStateOf(store.all()) }
    var selected by remember { mutableLongStateOf(store.selected()) }
    var tab by remember { mutableIntStateOf(0) }
    var addMode by remember { mutableStateOf(tvs.isEmpty()) }
    var brand by remember { mutableStateOf(Brands.first()) }
    var tvName by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var theme by remember { mutableStateOf("Sistem") }
    var textSize by remember { mutableStateOf("Standart") }
    var listening by remember { mutableStateOf(store.listening()) }
    val current = tvs.firstOrNull { it.id == selected } ?: tvs.firstOrNull()
    val fontScale = when (textSize) { "Büyük" -> 1.12f; "Çok büyük" -> 1.25f; else -> 1f }
    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, background = Page, surface = Color.White)) {
        Scaffold(containerColor = Page, topBar = {
            TopAppBar(title = { Column { Text("Kumanda+", fontWeight = FontWeight.Bold); Text(current?.name ?: "Televizyon ekle", fontSize = 12.sp, color = Color.Gray) } }, actions = {
                if (!addMode && tvs.isNotEmpty()) { IconButton(onClick = { tab = 3 }) { Icon(Icons.Default.Tv, "Televizyonlar") } }
            })
        }, bottomBar = {
            if (!addMode && tvs.isNotEmpty()) NavigationBar {
                listOf("Ana sayfa", "Kumanda", "Sesli komut", "Televizyonlar", "Ayarlar").forEachIndexed { i, label ->
                    val icons = listOf(Icons.Default.Home, Icons.Default.Tune, Icons.Default.Mic, Icons.Default.Tv, Icons.Default.Settings)
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                if (addMode) AddTvScreen(tvName, { tvName = it }, brand, { brand = it }, onSave = {
                    val newTv = TvProfile(System.currentTimeMillis(), tvName.ifBlank { "$brand TV" }, brand)
                    tvs = tvs + newTv; store.save(tvs); selected = newTv.id; store.select(selected); addMode = false; tab = 0
                })
                else when (tab) {
                    0 -> HomeScreen(current, listening, ir, onStartVoice, onStopVoice, { listening = it })
                    1 -> RemoteScreen(current, ir)
                    2 -> VoiceScreen(listening, onStartVoice, onStopVoice)
                    3 -> TvListScreen(tvs, selected, onSelect = { selected = it; store.select(it); tab = 0 }, onAdd = { addMode = true }, onDelete = { id -> tvs = tvs.filterNot { it.id == id }; store.save(tvs); if (selected == id) { selected = tvs.firstOrNull()?.id ?: -1; store.select(selected) }; if (tvs.isEmpty()) addMode = true })
                    else -> SettingsScreen(theme, { theme = it }, textSize, { textSize = it }, onStopVoice)
                }
            }
        }
    }
}

@Composable
fun AddTvScreen(name: String, onName: (String) -> Unit, brand: String, onBrand: (String) -> Unit, onSave: () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Televizyonunu ekle", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Markanı seç ve televizyonuna bir ad ver. IR profil eşleştirme testi sonraki kurulum adımında yapılacak.", color = Color.DarkGray)
        OutlinedTextField(value = name, onValueChange = onName, label = { Text("Televizyon adı (ör. Salon TV)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(value = brand, onValueChange = {}, readOnly = true, label = { Text("Marka") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { Brands.forEach { b -> DropdownMenuItem(text = { Text(b) }, onClick = { onBrand(b); expanded = false }) } }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) { Text("Televizyonu ekle") }
    }
}

@Composable
fun HomeScreen(tv: TvProfile?, listening: Boolean, ir: IrController, onStart: () -> Unit, onStop: () -> Unit, onListening: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2EF)), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tv?.name ?: "TV seçilmedi", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(tv?.brand ?: "Önce bir televizyon ekleyin", color = Color.DarkGray)
                Text("Kızılötesi kumanda", color = Teal, fontWeight = FontWeight.SemiBold)
            }
        }
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Mic, null, tint = Teal); Spacer(Modifier.width(8.dp)); Text("Sesli kumanda", fontWeight = FontWeight.Bold) }
                Text(if (listening) "Dinleme hizmeti açık. Uyandırma motoru henüz projeye eklenmedi." else "Hey Kumanda özelliğini kullanmak için dinlemeyi etkinleştir.", color = Color.DarkGray)
                Button(onClick = { if (listening) onStop() else onStart(); onListening(!listening) }, modifier = Modifier.fillMaxWidth()) { Text(if (listening) "Dinlemeyi durdur" else "Dinlemeyi etkinleştir") }
            }
        }
        Text("Hızlı kumanda", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            QuickButton("Ses −", Icons.Default.VolumeDown, Modifier.weight(1f)) { ir.send("VOL_DOWN") }
            QuickButton("Ses +", Icons.Default.VolumeUp, Modifier.weight(1f)) { ir.send("VOL_UP") }
            QuickButton("Güç", Icons.Default.PowerSettingsNew, Modifier.weight(1f)) { ir.send("POWER") }
        }
        Text("Not: IR sinyalleri ve çevrimdışı ses modelleri doğrulanmadan çalışıyor olarak gösterilmez.", fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable
fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(76.dp), shape = RoundedCornerShape(16.dp)) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null); Text(label) } }
}

@Composable
fun RemoteScreen(tv: TvProfile?, ir: IrController) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tv?.name ?: "TV", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Button(onClick = { ir.send("POWER") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PowerSettingsNew, null); Spacer(Modifier.width(8.dp)); Text("Aç / Kapat") }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Button(onClick = { ir.send("VOL_DOWN") }) { Icon(Icons.Default.Remove, null); Text("Ses") }
            Button(onClick = { ir.send("VOL_UP") }) { Icon(Icons.Default.Add, null); Text("Ses") }
        }
        Text("Kanal tuşları", fontWeight = FontWeight.Bold)
        (1..3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { (0..2).forEach { col -> val n = (row - 1) * 3 + col + 1; NumberKey(n.toString()) { ir.send("DIGIT_$n") } } } }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { NumberKey("YouTube") { ir.send("YOUTUBE") }; NumberKey("0") { ir.send("DIGIT_0") }; NumberKey("Home") { ir.send("HOME") } }
        Text("Not: Bu başlangıç paketinde henüz doğrulanmış IR kod veritabanı yoktur. Tuş arayüzü hazır; kodlar eklendiğinde sinyal gönderir.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun NumberKey(text: String, onClick: () -> Unit) { OutlinedButton(onClick = onClick, modifier = Modifier.sizeIn(minWidth = 76.dp, minHeight = 48.dp), shape = RoundedCornerShape(14.dp)) { Text(text) } }

@Composable
fun VoiceScreen(listening: Boolean, onStart: () -> Unit, onStop: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Mic, null, tint = Teal, modifier = Modifier.size(70.dp))
        Spacer(Modifier.height(16.dp)); Text("Hey Kumanda", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(if (listening) "Dinleme hizmeti açık" else "Dinleme kapalı", color = Color.Gray)
        Spacer(Modifier.height(20.dp)); Button(onClick = { if (listening) onStop() else onStart() }) { Text(if (listening) "Durdur" else "Başlat") }
        Spacer(Modifier.height(12.dp)); Text("Çevrimdışı uyandırma kelimesi ve konuşma tanıma modelleri henüz eklenmedi.", color = Color.Gray)
    }
}

@Composable
fun TvListScreen(tvs: List<TvProfile>, selected: Long, onSelect: (Long) -> Unit, onAdd: () -> Unit, onDelete: (Long) -> Unit) {
    var pendingDelete by remember { mutableStateOf<TvProfile?>(null) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Televizyonlar", fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Button(onClick = onAdd) { Text("Ekle +") } }
        LazyColumn { items(tvs, key = { it.id }) { tv -> Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), onClick = { onSelect(tv.id) }) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Tv, null, tint = Teal); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(tv.name, fontWeight = FontWeight.Bold); Text(tv.brand, color = Color.Gray, fontSize = 12.sp) }; if (tv.id == selected) Icon(Icons.Default.CheckCircle, null, tint = Teal); IconButton(onClick = { pendingDelete = tv }) { Icon(Icons.Default.Delete, null) } } } } }
    }
    pendingDelete?.let { tv -> AlertDialog(onDismissRequest = { pendingDelete = null }, title = { Text("Televizyon silinsin mi?") }, text = { Text("${tv.name} profili silinecek.") }, confirmButton = { TextButton(onClick = { onDelete(tv.id); pendingDelete = null }) { Text("Sil") } }, dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Vazgeç") } }) }
}

@Composable
fun SettingsScreen(theme: String, onTheme: (String) -> Unit, size: String, onSize: (String) -> Unit, stopVoice: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Ayarlar", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Tema", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Açık", "Koyu", "Sistem").forEach { FilterChip(selected = theme == it, onClick = { onTheme(it) }, label = { Text(it) }) } }
        Text("Yazı boyutu", fontWeight = FontWeight.Bold); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Standart", "Büyük", "Çok büyük").forEach { FilterChip(selected = size == it, onClick = { onSize(it) }, label = { Text(it) }) } }
        OutlinedButton(onClick = stopVoice, modifier = Modifier.fillMaxWidth()) { Text("Sesli dinlemeyi durdur") }
        Text("Kumanda+ 0.0.1 · İnternet bağlantısı kullanılmaz", color = Color.Gray, fontSize = 12.sp)
    }
}
