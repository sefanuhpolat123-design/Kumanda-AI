# IR profile sources

- LG unknown-model TV profile: https://github.com/Lucaslhm/Flipper-IRDB/blob/main/TVs/LG/LG.ir
- Samsung TV 2 profile: https://github.com/Lucaslhm/Flipper-IRDB/blob/main/TVs/Samsung/Samsung_TV_2.ir
- Upstream repository license: CC0-1.0 (repository README and LICENSE).

Only the published commands from those exact files are included. No digits, YouTube, or other unlisted commands are fabricated. Samsung profile uses the Samsung32 protocol; LG uses NEC. These are model/profile-specific examples and are not guaranteed for every TV of the same brand.
