package com.kumandaplus.app.ir

/** Gönderilmeye hazır IR sinyali: taşıyıcı frekans (Hz) + mikrosaniye cinsinden işaret/boşluk dizisi. */
data class IrPattern(val carrierHz: Int, val pattern: IntArray) {
    init {
        require(carrierHz in 20_000..60_000) { "Geçersiz taşıyıcı frekansı: $carrierHz" }
        require(pattern.isNotEmpty() && pattern.size % 2 == 1 || pattern.isNotEmpty()) { "Boş örüntü" }
    }
    override fun equals(other: Any?) = other is IrPattern && carrierHz == other.carrierHz && pattern.contentEquals(other.pattern)
    override fun hashCode() = 31 * carrierHz + pattern.contentHashCode()
}
