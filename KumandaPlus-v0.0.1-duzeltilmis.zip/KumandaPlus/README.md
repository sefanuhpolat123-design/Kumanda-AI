# Kumanda+ (v0.0.1)

Android IR kumanda uygulamasının başlangıç kaynak projesi.

## Derleme

Proje Java 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2 ve Kotlin 2.1.20 kullanır.
GitHub Actions üzerinden manuel derleme için depo kökündeki workflow dosyası kullanılır.

## Otomatik tetikleme yok

Bu kaynak ZIP'in içinde `.github/workflows` klasörü bulunmaz. ZIP'i depoya yüklemek
tek başına derleme başlatmaz. Derleme yalnızca GitHub Actions ekranından manuel
olarak başlatılır.

## Mevcut durum

Bu paket bir başlangıç iskeletidir; tüm planlanan IR profilleri, çevrimdışı ses
motoru ve gelişmiş sesli komut özellikleri henüz tamamlanmış değildir.
