package com.kumandaplus.app

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.concurrent.Executors

/** Sequential IR transmitter. Codes are intentionally data-driven; verified brand profiles must be added to IrLibrary. */
class IrController(private val context: Context) {
    private val manager = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    private val queue = Executors.newSingleThreadExecutor()
    fun hasEmitter(): Boolean = manager?.hasIrEmitter() == true
    fun send(key: String) {
        val profile = IrLibrary.profileFor(context)
        val pattern = profile[key]
        if (manager?.hasIrEmitter() != true || pattern == null) {
            Handler(Looper.getMainLooper()).post { Toast.makeText(context, if (pattern == null) "Bu TV profili için $key sinyali henüz eklenmedi." else "Bu telefonda IR vericisi bulunamadı.", Toast.LENGTH_SHORT).show() }
            return
        }
        queue.execute {
            try { manager.transmit(38000, pattern) }
            catch (_: Exception) { Handler(Looper.getMainLooper()).post { Toast.makeText(context, "IR sinyali gönderilemedi.", Toast.LENGTH_SHORT).show() } }
        }
    }
}

/** Placeholder library: never reports a made-up working code. Add verified raw patterns per remote profile. */
object IrLibrary {
    fun profileFor(context: Context): Map<String, IntArray> = emptyMap()
}
