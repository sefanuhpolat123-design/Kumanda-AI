package com.kumanda.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

object VoiceState {
    val running = MutableStateFlow(false)
    val last = MutableStateFlow("")
}

/**
 * "Hey kumanda ..." dinleyen ön plan servisi.
 * Android'in Türkçe ses tanımasını sürekli döngüyle kullanır; cümlede "kumanda" geçince
 * sonrasındaki komutu çalıştırır. Sadece "hey kumanda" denirse 7 sn içinde gelen cümleyi komut sayar.
 */
class VoiceService : Service() {
    private var rec: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var armedUntil = 0L
    private var stopped = false
    private var muted = false
    private val wake = Regex("kumand\\w*")

    companion object {
        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, VoiceService::class.java))
        }
        fun stop(c: Context) {
            c.stopService(Intent(c, VoiceService::class.java))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = notif("Dinliyor: \"Hey kumanda…\"")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        if (rec == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                VoiceState.last.value = "Ses tanıma servisi bulunamadı (Google uygulaması gerekli)"
                stopSelf()
                return START_NOT_STICKY
            }
            rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
            muteBeep(true)
            VoiceState.running.value = true
            listen()
        }
        return START_NOT_STICKY
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("voice", "Sesli komut", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, VoiceService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "voice")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Kumanda")
            .setContentText(text)
            .setOngoing(true)
            .addAction(0, "Durdur", stop)
            .build()
    }

    /** Ses tanıma "bip"ini önlemek için telefonun medya sesini dinleme sırasında kısar. */
    private fun muteBeep(on: Boolean) {
        val am = getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE,
            0
        )
        muted = on
    }

    private fun listen() {
        if (stopped) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            rec?.startListening(i)
        } catch (e: Exception) {
            h.postDelayed({ listen() }, 1000)
        }
    }

    private fun handle(list: List<String>) {
        val now = SystemClock.elapsedRealtime()
        val cands = list.map { Commands.norm(it) }.filter { it.isNotEmpty() }
        var cmd: String? = null
        for (t in cands) {
            val m = wake.findAll(t).lastOrNull()
            if (m != null) {
                cmd = t.substring(m.range.last + 1).trim()
                break
            }
        }
        if (cmd == null && now < armedUntil) cmd = cands.firstOrNull()
        if (cmd == null) return
        if (cmd.isEmpty()) {
            armedUntil = now + 7000
            VoiceState.last.value = "Dinliyorum, komutu söyle…"
            return
        }
        armedUntil = 0
        val res = Commands.run(applicationContext, cmd)
        VoiceState.last.value = "\"$cmd\" → $res"
        getSystemService(NotificationManager::class.java).notify(1, notif("$cmd → $res"))
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                VoiceState.last.value = "Mikrofon izni yok"
                stopSelf()
                return
            }
            val busy = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
            if (busy) rec?.cancel()
            h.postDelayed({ listen() }, if (busy) 1000L else 300L)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            handle(list)
            h.postDelayed({ listen() }, 300)
        }
    }

    override fun onDestroy() {
        stopped = true
        h.removeCallbacksAndMessages(null)
        rec?.destroy()
        rec = null
        if (muted) muteBeep(false)
        VoiceState.running.value = false
        super.onDestroy()
    }
}
