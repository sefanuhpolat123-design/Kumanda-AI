package com.kumandaplus.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

enum class RKey(val label: String) {
    POWER("Güç"), POWER_ON("Aç"), POWER_OFF("Kapat"),
    VOL_UP("Ses +"), VOL_DOWN("Ses -"), MUTE("Sessiz"),
    D0("0"), D1("1"), D2("2"), D3("3"), D4("4"), D5("5"), D6("6"), D7("7"), D8("8"), D9("9"),
    HOME("Home"), YOUTUBE("YouTube")
}

@Entity
data class TvEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val brand: String,
    val address: Int, val carrierHz: Int = 38000, val lastUsed: Long = 0
)

@Entity(primaryKeys = ["tvId", "keyName"])
data class KeyEntity(val tvId: Long, val keyName: String, val command: Int)

@Entity
data class ChannelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tvId: Long, val number: Int, val name: String
)

@Entity
data class SettingEntity(@PrimaryKey val k: String, val v: String)

@Dao
interface AppDao {
    @Query("SELECT * FROM TvEntity ORDER BY lastUsed DESC LIMIT 1") suspend fun currentOnce(): TvEntity?
    @Query("SELECT * FROM KeyEntity WHERE tvId = :id") suspend fun keysOnce(id: Long): List<KeyEntity>
    @Query("SELECT * FROM ChannelEntity WHERE tvId = :id ORDER BY number") suspend fun channelsOnce(id: Long): List<ChannelEntity>
    @Query("SELECT * FROM SettingEntity") fun settings(): Flow<List<SettingEntity>>
    @Query("SELECT v FROM SettingEntity WHERE k = :k") suspend fun setting(k: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSetting(s: SettingEntity)
    @Query("SELECT * FROM TvEntity ORDER BY name") fun tvs(): Flow<List<TvEntity>>
    @Query("SELECT * FROM TvEntity ORDER BY lastUsed DESC LIMIT 1") fun current(): Flow<TvEntity?>
    @Insert suspend fun insertTv(t: TvEntity): Long
    @Query("UPDATE TvEntity SET lastUsed = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
    @Query("DELETE FROM TvEntity WHERE id = :id") suspend fun deleteTv(id: Long)
    @Query("DELETE FROM KeyEntity WHERE tvId = :id") suspend fun deleteKeys(id: Long)
    @Query("DELETE FROM ChannelEntity WHERE tvId = :id") suspend fun deleteChannels(id: Long)
    @Query("SELECT * FROM KeyEntity WHERE tvId = :id") fun keys(id: Long): Flow<List<KeyEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putKey(k: KeyEntity)
    @Query("SELECT * FROM ChannelEntity WHERE tvId = :id ORDER BY number") fun channels(id: Long): Flow<List<ChannelEntity>>
    @Insert suspend fun addChannel(c: ChannelEntity)
    @Query("DELETE FROM ChannelEntity WHERE id = :id") suspend fun deleteChannel(id: Long)
}

@Database(entities = [TvEntity::class, KeyEntity::class, ChannelEntity::class, SettingEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        private val M12 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `SettingEntity` (`k` TEXT NOT NULL, `v` TEXT NOT NULL, PRIMARY KEY(`k`))")
            }
        }
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "kumanda.db")
                .addMigrations(M12).build().also { inst = it }
        }
    }
}

/**
 * Doğrulanmış profil verisi. Kaynak: IRDB (probonopd/irdb, codes/Toshiba/TV/64,-1.csv) ve
 * bağımsız kaynaklar: Toshiba = NEC1, cihaz 64 (0x40); Güç(toggle)=18, Güç AÇ=126, Güç KAPAT=127
 * (kapat = 40 BF 7F 80). Ses/rakam kodları bu belgede doğrulanamadı -> "Tuş öğren" ile TV'den bulunur.
 */
object Profiles {
    data class Seed(val brand: String, val address: Int, val keys: Map<RKey, Int>, val source: String)
    val all = listOf(
        Seed("Toshiba", 64, mapOf(RKey.POWER to 18, RKey.POWER_ON to 126, RKey.POWER_OFF to 127),
            "IRDB Toshiba/TV/64,-1 (NEC1)")
    )
    fun seedFor(brand: String) = all.firstOrNull { it.brand.equals(brand, true) }
}
