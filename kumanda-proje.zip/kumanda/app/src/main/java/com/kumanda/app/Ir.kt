package com.kumanda.app

import android.content.Context
import android.hardware.ConsumerIrManager

/** NEC protokolü ile IR gönderir (Toshiba TV'ler genelde NEC kullanır). */
object Ir {
    private fun mgr(c: Context): ConsumerIrManager? =
        c.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun available(c: Context): Boolean = mgr(c)?.hasIrEmitter() == true

    fun nec(addr: Int, cmd: Int): IntArray {
        val p = mutableListOf<Int>()
        p += 9000
        p += 4500
        fun byte(b: Int) {
            for (i in 0 until 8) {
                p += 560
                p += if (((b shr i) and 1) == 1) 1690 else 560
            }
        }
        byte(addr and 0xFF)
        byte(addr.inv() and 0xFF)
        byte(cmd and 0xFF)
        byte(cmd.inv() and 0xFF)
        p += 560
        return p.toIntArray()
    }

    fun send(c: Context, addr: Int, cmd: Int): Boolean {
        val m = mgr(c) ?: return false
        if (!m.hasIrEmitter()) return false
        m.transmit(38000, nec(addr, cmd))
        return true
    }
}
