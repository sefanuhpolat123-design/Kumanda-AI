package com.kumanda.app

import android.content.Context
import java.util.Locale
import java.util.concurrent.Executors

/** Türkçe sesli komutları IR tuşlarına çevirir. */
object Commands {
    private val io = Executors.newSingleThreadExecutor()

    fun norm(s: String): String =
        s.lowercase(Locale.forLanguageTag("tr"))
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private val NUM = listOf(
        "sıfır" to 0, "yirmi" to 20, "otuz" to 30, "kırk" to 40, "elli" to 50,
        "altmış" to 60, "yetmiş" to 70, "seksen" to 80, "doksan" to 90,
        "dokuz" to 9, "dört" to 4, "dörd" to 4, "beş" to 5, "altı" to 6,
        "yedi" to 7, "sekiz" to 8, "iki" to 2, "üç" to 3, "bir" to 1,
        "yüz" to 100, "on" to 10
    )

    fun parseNumber(w: List<String>): Int? {
        for (x in w) if (x.isNotEmpty() && x.all { it.isDigit() }) return x.toIntOrNull()
        var sum = 0
        var found = false
        for (x in w) {
            val e = NUM.firstOrNull { x.startsWith(it.first) && x.length - it.first.length <= 3 }
            if (e != null) { sum += e.second; found = true }
        }
        return if (found) sum else null
    }

    private fun send(c: Context, keys: List<Key>, desc: String): String {
        val missing = keys.firstOrNull { Store.code(c, it) < 0 }
        if (missing != null) return "${missing.label} kodu atanmamış (Keşif sekmesi)"
        if (!Ir.available(c)) return "IR vericisi yok"
        io.execute {
            keys.forEachIndexed { i, k ->
                Store.press(c, k)
                if (i < keys.lastIndex) Thread.sleep(450)
            }
        }
        return desc
    }

    private fun channel(c: Context, num: Int, name: String): String =
        send(c, num.toString().map { Key.valueOf("D$it") }, "Kanal $num ($name)")

    fun run(ctx: Context, text: String): String {
        val c = ctx.applicationContext
        val t = norm(text)
        val w = t.split(" ").filter { it.isNotEmpty() }
        val flat = t.replace(" ", "")
        fun has(vararg s: String) = s.any { x -> w.any { it.startsWith(x) } }
        val n = parseNumber(w)

        // 1) uygulama tuşları
        if (flat.contains("youtube") || flat.contains("yutup")) return send(c, listOf(Key.YOUTUBE), "YouTube")
        if (flat.contains("netflix")) return send(c, listOf(Key.NETFLIX), "Netflix")
        if (flat.contains("prime") || flat.contains("amazon")) return send(c, listOf(Key.PRIME), "Prime Video")

        // 2) kullanıcının tanımladığı kanal adları (Show TV, ATV ...)
        val ch = Store.channelMap(c).entries
            .sortedByDescending { it.key.length }
            .firstOrNull { flat.contains(it.key) }
        if (ch != null) return channel(c, ch.value, ch.key)

        // 3) ses
        if (has("sustur", "sessiz") || (has("ses") && has("kapat", "kes")))
            return send(c, listOf(Key.MUTE), "Sessiz")
        if (has("ses")) {
            val vt = (n ?: 1).coerceIn(1, 30)
            return when {
                has("kıs", "azal", "düşür", "alçal") -> send(c, List(vt) { Key.VOL_DOWN }, "Ses − ×$vt")
                has("aç", "art", "yüksel", "fazla", "güçlen") -> send(c, List(vt) { Key.VOL_UP }, "Ses + ×$vt")
                else -> "ses komutu anlaşılmadı"
            }
        }

        // 4) kanal ileri / geri
        if (has("kanal")) {
            if (has("sonraki", "art", "ileri", "yukarı")) return send(c, listOf(Key.CH_UP), "Kanal +")
            if (has("önceki", "azal", "geri", "aşağı")) return send(c, listOf(Key.CH_DOWN), "Kanal −")
        }

        // 5) gezinme / diğer tuşlar
        if (flat.contains("anaekran") || flat.contains("anasayfa") || has("home"))
            return send(c, listOf(Key.HOME), "Ana ekran")
        val nt = (n ?: 1).coerceIn(1, 10)
        val nav = listOf(
            listOf("yukarı") to Key.UP, listOf("aşağı") to Key.DOWN,
            listOf("sağ") to Key.RIGHT, listOf("sol") to Key.LEFT,
            listOf("tamam", "onay", "seç") to Key.OK, listOf("geri") to Key.BACK,
            listOf("menü") to Key.MENU, listOf("kaynak") to Key.INPUT,
            listOf("bilgi") to Key.INFO, listOf("çık") to Key.EXIT,
            listOf("rehber") to Key.GUIDE, listOf("ayar") to Key.SETTINGS,
            listOf("oynat", "devam") to Key.PLAY, listOf("duraklat", "dur") to Key.PAUSE
        )
        val hit = nav.firstOrNull { (ws, _) -> has(*ws.toTypedArray()) }
        if (hit != null) return send(c, List(nt) { hit.second }, hit.second.label)

        // 6) kanal numarası: "beşi aç", "on iki", "kanal 7"
        if (n != null && n in 0..999) return channel(c, n, n.toString())

        // 7) güç: sadece kısa komutlar ("televizyonu kapat", "tv aç")
        val isTv = w.any { it == "tv" || it.startsWith("televizyon") }
        if (w.size <= 2 && ((isTv && has("aç", "kapat", "kapa")) || (w.size == 1 && has("kapat"))))
            return send(c, listOf(Key.POWER), "TV aç/kapat")

        return "anlaşılmadı"
    }
}
