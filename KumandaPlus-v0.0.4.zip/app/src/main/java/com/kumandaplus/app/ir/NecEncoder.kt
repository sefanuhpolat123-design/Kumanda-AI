package com.kumandaplus.app.ir

/**
 * NEC protokolü kodlayıcı (38 kHz varsayılan; profil başka frekans isterse parametre ile verilir).
 * Bitler LSB önce gönderilir. Adres 0..255 ise standart (adres + ters adres),
 * 0..65535 ise genişletilmiş NEC (16 bit adres) kullanılır.
 */
object NecEncoder {
    private const val HEADER_MARK = 9000
    private const val HEADER_SPACE = 4500
    private const val BIT_MARK = 560
    private const val ZERO_SPACE = 560
    private const val ONE_SPACE = 1690

    fun encode(address: Int, command: Int, carrierHz: Int = 38_000): IrPattern {
        require(address in 0..0xFFFF) { "Adres aralık dışı" }
        require(command in 0..0xFF) { "Komut aralık dışı" }
        val addrBits = if (address <= 0xFF) (address or ((address.inv() and 0xFF) shl 8)) else address
        val cmdBits = command or ((command.inv() and 0xFF) shl 8)
        val frame = (addrBits.toLong() and 0xFFFF) or ((cmdBits.toLong() and 0xFFFF) shl 16)
        val out = ArrayList<Int>(68)
        out += HEADER_MARK; out += HEADER_SPACE
        for (i in 0 until 32) {
            out += BIT_MARK
            out += if ((frame shr i) and 1L == 1L) ONE_SPACE else ZERO_SPACE
        }
        out += BIT_MARK
        return IrPattern(carrierHz, out.toIntArray())
    }
}
