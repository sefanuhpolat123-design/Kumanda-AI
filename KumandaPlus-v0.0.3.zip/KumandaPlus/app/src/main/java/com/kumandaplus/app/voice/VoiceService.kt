package com.kumandaplus.app.voice

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.kumandaplus.app.data.AppDb
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.StorageService

enum class VStatus { Off, Loading, Wake, Command, NoModel }

object VoiceState {
    val status = MutableStateFlow(VStatus.Off)
    val last = MutableStateFlow("")
}

/** Ön plan mikrofon servisi: "Hey Kumanda" bekler -> 10 sn komut dinler -> uygular -> beklemeye döner. */
class VoiceService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Sesli dinleme", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH).setContentTitle("Kumanda+ dinliyor")
            .setContentText("Mikrofon açık. Kapatmak için dokun.").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).setContentIntent(stop).addAction(Notification.Action.Builder(null, "Kapat", stop).build()).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (job == null) job = scope.launch { try { loop() } finally { VoiceState.status.value = VStatus.Off; stopSelf() } }
        return START_NOT_STICKY // yeniden başlatmada kendiliğinden dinlemeye başlamaz
    }

    private suspend fun loadModel(): Model? {
        if (assets.list("model").isNullOrEmpty()) return null
        val d = CompletableDeferred<Model?>()
        StorageService.unpack(this, "model", "model", { m -> d.complete(m) },
            { e -> VoiceState.last.value = "Model hatası: ${e.message}"; d.complete(null) })
        return d.await()
    }

    private suspend fun loop() {
        VoiceState.status.value = VStatus.Loading
        val model = loadModel()
        if (model == null) { VoiceState.status.value = VStatus.NoModel; return }
        val phrase = CommandParser.tokens(AppDb.get(this).dao().setting("wake") ?: "hey kumanda").joinToString(" ")
        val key = phrase.substringAfterLast(' ')
        val wake = Recognizer(model, 16000f, JSONArray(listOf(phrase, key, "[unk]")).toString())
        val cmdRec = Recognizer(model, 16000f)
        val engine = RemoteEngine(this)
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, minBuf * 4)
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
        try {
            rec.startRecording()
            VoiceState.status.value = VStatus.Wake
            val buf = ByteArray(4096)
            var listening = false
            var deadline = 0L
            while (currentCoroutineContext().isActive) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (!listening) {
                    val heard = if (wake.acceptWaveForm(buf, n)) JSONObject(wake.result).optString("text")
                    else JSONObject(wake.partialResult).optString("partial")
                    if (heard.split(" ").contains(key)) {
                        wake.reset(); cmdRec.reset(); listening = true
                        deadline = System.currentTimeMillis() + 10_000
                        VoiceState.status.value = VStatus.Command
                        VoiceState.last.value = "Dinliyorum…"
                        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
                    }
                } else {
                    var text = ""
                    if (cmdRec.acceptWaveForm(buf, n)) text = JSONObject(cmdRec.result).optString("text")
                    val timeUp = System.currentTimeMillis() > deadline
                    if (text.isBlank() && timeUp) text = JSONObject(cmdRec.finalResult).optString("text")
                    if (text.isNotBlank()) {
                        val res = engine.run(CommandParser.parse(text))
                        VoiceState.last.value = "\"$text\" → $res"
                        listening = false; wake.reset(); VoiceState.status.value = VStatus.Wake
                    } else if (timeUp) {
                        VoiceState.last.value = "Komut duyulmadı."
                        listening = false; wake.reset(); VoiceState.status.value = VStatus.Wake
                    }
                }
            }
        } finally {
            runCatching { rec.stop() }; rec.release(); tone.release()
            wake.close(); cmdRec.close(); model.close()
        }
    }

    override fun onDestroy() { scope.cancel(); VoiceState.status.value = VStatus.Off; super.onDestroy() }

    companion object {
        const val CH = "voice"; const val ACTION_STOP = "stop"
        fun start(c: Context) = ContextCompat.startForegroundService(c, Intent(c, VoiceService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, VoiceService::class.java)) }
    }
}
