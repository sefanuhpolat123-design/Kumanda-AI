package com.kumandaplus.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kumandaplus.app.data.*
import com.kumandaplus.app.ir.*
import com.kumandaplus.app.voice.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class Scan(val key: RKey, val code: Int, val running: Boolean)

@OptIn(ExperimentalCoroutinesApi::class)
class MainVm(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val ir = IrTransmitter(app)
    val hasIr = ir.hasIrEmitter()

    val tvs = dao.tvs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val current = dao.current().stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val keys = current.flatMapLatest { tv -> if (tv == null) flowOf(emptyList()) else dao.keys(tv.id) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val channels = current.flatMapLatest { tv -> if (tv == null) flowOf(emptyList()) else dao.channels(tv.id) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val message = MutableStateFlow<String?>(null)
    val scan = MutableStateFlow<Scan?>(null)
    private var scanJob: Job? = null

    private suspend fun sendCode(tv: TvEntity, cmd: Int): Boolean =
        when (val r = ir.send(NecEncoder.encode(tv.address, cmd, tv.carrierHz))) {
            IrResult.Sent -> true
            IrResult.NoHardware -> { message.value = "Bu telefonda IR vericisi yok."; false }
            is IrResult.Failed -> { message.value = "Gönderim hatası: ${r.message}"; lastError.value = r.cause?.stackTraceToString() ?: r.message; false }
        }

    private fun codeOf(k: RKey): Int? = keys.value.firstOrNull { it.keyName == k.name }?.command

    fun press(k: RKey) {
        viewModelScope.launch {
            val tv = current.value ?: return@launch
            val cmd = codeOf(k)
            if (cmd == null) {
                message.value = "${k.label} için kod yok. Tuşa basılı tutup öğret."
                return@launch
            }
            sendCode(tv, cmd)
        }
    }

    fun tune(ch: ChannelEntity) {
        viewModelScope.launch {
            val tv = current.value ?: return@launch
            for (d in ch.number.toString()) {
                val k = RKey.valueOf("D$d")
                val cmd = codeOf(k)
                if (cmd == null) { message.value = "${k.label} rakamı öğrenilmemiş."; return@launch }
                if (!sendCode(tv, cmd)) return@launch
                delay(400)
            }
        }
    }

    fun addTv(name: String, brand: String, address: Int) {
        viewModelScope.launch {
            val id = dao.insertTv(TvEntity(name = name.trim(), brand = brand, address = address,
                lastUsed = System.currentTimeMillis()))
            Profiles.seedFor(brand)?.keys?.forEach { (k, c) -> dao.putKey(KeyEntity(id, k.name, c)) }
        }
    }

    fun select(tv: TvEntity) { viewModelScope.launch { dao.touch(tv.id, System.currentTimeMillis()) } }

    fun deleteTv(tv: TvEntity) {
        viewModelScope.launch { dao.deleteKeys(tv.id); dao.deleteChannels(tv.id); dao.deleteTv(tv.id) }
    }

    fun addChannel(number: Int, name: String) {
        val tv = current.value ?: return
        viewModelScope.launch { dao.addChannel(ChannelEntity(tvId = tv.id, number = number, name = name.trim())) }
    }

    fun deleteChannel(c: ChannelEntity) { viewModelScope.launch { dao.deleteChannel(c.id) } }

    /** Kod arama: 0..255 komutlarını sırayla gönderir; TV tepki verince kullanıcı "Oldu" der. */
    fun startScan(key: RKey, from: Int = 0) {
        val tv = current.value ?: return
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            for (c in from..255) {
                scan.value = Scan(key, c, true)
                if (!sendCode(tv, c)) { scan.value = null; return@launch }
                delay(1500)
            }
            scan.value = scan.value?.copy(running = false)
            message.value = "256 kodun hiçbiri çalışmadı. Adres/marka yanlış olabilir."
        }
    }

    fun scanFound() {
        val s = scan.value ?: return
        val tv = current.value ?: return
        scanJob?.cancel()
        viewModelScope.launch {
            dao.putKey(KeyEntity(tv.id, s.key.name, s.code))
            scan.value = null
            message.value = "${s.key.label} kaydedildi (kod ${s.code})."
        }
    }

    fun scanBack() { val s = scan.value ?: return; startScan(s.key, maxOf(0, s.code - 1)) }
    fun scanStop() { scanJob?.cancel(); scan.value = null }

    val engine = RemoteEngine(app)
    val settings = dao.settings().map { l -> l.associate { it.k to it.v } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
    val lastError = MutableStateFlow<String?>(null)
    fun setSetting(k: String, v: String) { viewModelScope.launch { dao.putSetting(SettingEntity(k, v)) } }
    suspend fun hasAnyTv() = dao.currentOnce() != null
    fun runText(t: String) {
        viewModelScope.launch {
            message.value = engine.run(CommandParser.parse(t))
            engine.lastError?.let { lastError.value = it }
        }
    }
}
