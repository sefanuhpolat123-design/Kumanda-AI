package com.kumandaplus.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.kumandaplus.app.voice.VStatus
import com.kumandaplus.app.voice.VoiceService
import com.kumandaplus.app.voice.VoiceState

@Composable
fun VoiceScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val st by VoiceState.status.collectAsState()
    val last by VoiceState.last.collectAsState()
    val wake = vm.settings.collectAsState().value["wake"] ?: "hey kumanda"
    var text by remember { mutableStateOf("") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) VoiceService.start(ctx)
        else vm.message.value = "Mikrofon izni verilmedi; sesli dinleme başlatılamaz."
    }
    val active = st == VStatus.Wake || st == VStatus.Command || st == VStatus.Loading
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        1f, 1.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "s")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Surface(shape = CircleShape, modifier = Modifier.size(110.dp).graphicsLayer {
            val sc = if (st == VStatus.Command) pulse else if (st == VStatus.Wake) 1f + (pulse - 1f) / 3f else 1f
            scaleX = sc; scaleY = sc
        }, color = when (st) {
            VStatus.Command -> MaterialTheme.colorScheme.primary
            VStatus.Wake, VStatus.Loading -> MaterialTheme.colorScheme.primaryContainer
            else -> MaterialTheme.colorScheme.surfaceVariant
        }) { Box(contentAlignment = Alignment.Center) { Text("MİK", style = MaterialTheme.typography.titleLarge) } }
        Text(when (st) {
            VStatus.Off -> "Dinleme kapalı"
            VStatus.Loading -> "Model yükleniyor…"
            VStatus.Wake -> "\"$wake\" bekleniyor"
            VStatus.Command -> "Komut söyle (10 sn)"
            VStatus.NoModel -> "Ses modeli APK'da yok. APK'yı GitHub Actions ile derle (model orada indirilir)."
        }, style = MaterialTheme.typography.titleMedium)
        if (last.isNotBlank()) Text(last)
        Button(onClick = {
            if (active) VoiceService.stop(ctx) else launcher.launch(
                if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                else arrayOf(Manifest.permission.RECORD_AUDIO))
        }) { Text(if (active) "Dinlemeyi kapat" else "Dinlemeyi başlat") }
        Text("Ses kaydedilmez, internete gönderilmez. Telefon yeniden başlarsa dinleme kendiliğinden açılmaz.",
            style = MaterialTheme.typography.bodySmall)
        Divider()
        Text("Mikrofonsuz dene (komutu yaz)", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(text, { text = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("örn: sesi artır, beşi aç, televizyonu kapat") })
        Button(enabled = text.isNotBlank(), onClick = { vm.runText(text) }) { Text("Dene") }
        Text("Desteklenen: sesi artır/azalt, sessiz, televizyonu aç/kapat, YouTube'u aç, beşi aç, beşinci kanala geç, " +
            "kanal beş, beş numaralı kanal, kanal adıyla aç. 'Sesi 15'e çıkar' IR ile mümkün olmadığı için uygulanmaz.",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SettingsScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    val tv by vm.current.collectAsState()
    val err by vm.lastError.collectAsState()
    val clip = LocalClipboardManager.current
    var wake by remember(s["wake"]) { mutableStateOf(s["wake"] ?: "hey kumanda") }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Tema", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to "Sistem", "light" to "Açık", "dark" to "Koyu").forEach { (k, l) ->
                FilterChip((s["theme"] ?: "system") == k, { vm.setSetting("theme", k) }, label = { Text(l) })
            }
        }
        Text("Yazı boyutu", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("1.0" to "Standart", "1.2" to "Büyük", "1.4" to "Çok büyük").forEach { (k, l) ->
                FilterChip((s["font"] ?: "1.0") == k, { vm.setSetting("font", k) }, label = { Text(l) })
            }
        }
        Text("Uyandırma kelimesi", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(wake, { wake = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(enabled = wake.isNotBlank(), onClick = {
            vm.setSetting("wake", wake.trim()); vm.message.value = "Kaydedildi. Dinlemeyi kapatıp yeniden aç."
        }) { Text("Kaydet") }
        Text("Seçili televizyon: ${tv?.name ?: "yok"}")
        Text("Sürüm: $version")
        Text("IR vericisi: ${if (vm.hasIr) "var" else "yok"}")
        err?.let { e ->
            Divider()
            Text("Son hata", style = MaterialTheme.typography.titleMedium)
            Text(e.take(600), style = MaterialTheme.typography.bodySmall)
            Button(onClick = { clip.setText(AnnotatedString(e)) }) { Text("Hatayı kopyala") }
        }
    }
}
