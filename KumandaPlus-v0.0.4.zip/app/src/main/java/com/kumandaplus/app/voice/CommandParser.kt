package com.kumandaplus.app.voice

import java.util.Locale

sealed class Cmd {
    object PowerOn : Cmd(); object PowerOff : Cmd()
    object VolUp : Cmd(); object VolDown : Cmd(); object Mute : Cmd()
    object YouTube : Cmd(); object Home : Cmd(); object Unknown : Cmd()
    data class VolSet(val level: Int) : Cmd()
    data class Channel(val number: Int) : Cmd()
    data class ChannelName(val compact: String) : Cmd()
}

/** Türkçe komut çözümleyici. Belirsiz cümlede Unknown döner (işlem yapılmaz). */
object CommandParser {
    private val tr = Locale("tr")
    private val NUM: Map<String, Int> = buildMap {
        fun add(v: Int, vararg w: String) = w.forEach { put(it, v) }
        add(0, "sıfır", "sıfırı"); add(1, "bir", "biri", "birinci"); add(2, "iki", "ikiyi", "ikinci")
        add(3, "üç", "üçü", "üçüncü"); add(4, "dört", "dördü", "dörde", "dördüncü")
        add(5, "beş", "beşi", "beşe", "beşinci"); add(6, "altı", "altıyı", "altıncı")
        add(7, "yedi", "yediyi", "yedinci"); add(8, "sekiz", "sekizi", "sekizinci")
        add(9, "dokuz", "dokuzu", "dokuzuncu"); add(10, "on", "onu", "onuncu", "ona")
        add(20, "yirmi", "yirmiyi", "yirminci"); add(30, "otuz", "otuzu"); add(40, "kırk", "kırkı")
        add(50, "elli", "ellisi"); add(60, "altmış", "altmışı"); add(70, "yetmiş", "yetmişi")
        add(80, "seksen", "sekseni"); add(90, "doksan", "doksanı"); add(100, "yüz", "yüzü")
    }
    private val STOP = setOf("aç", "açar", "geç", "izle", "kanalı", "kanal", "kanala", "lütfen", "hey",
        "kumanda", "bana", "numaralı", "numara")

    fun tokens(text: String): List<String> =
        text.lowercase(tr).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(" ").filter { it.isNotEmpty() }

    fun parseNumber(t: List<String>): Int? {
        var cur = 0; var seen = false
        for (w in t) {
            val v = NUM[w] ?: w.toIntOrNull()
            if (v == null) { if (seen) break else continue }
            if (v == 100 && w.startsWith("yüz")) cur = (if (cur == 0) 1 else cur) * 100 else cur += v
            seen = true
        }
        return if (seen) cur else null
    }

    fun compact(s: String) = tokens(s).joinToString("")

    fun parse(text: String): Cmd {
        val t = tokens(text)
        if (t.isEmpty()) return Cmd.Unknown
        fun has(vararg p: String) = t.any { w -> p.any { w.startsWith(it) } }
        val ses = t.any { it.startsWith("ses") && !it.startsWith("sessiz") }
        if (has("sessiz")) return Cmd.Mute
        if (ses && has("kapat", "kıs")) return if (has("kapat")) Cmd.Mute else Cmd.VolDown
        if (has("televizyon") && has("aç")) return Cmd.PowerOn
        if (has("kapat", "kapa") && !ses) return Cmd.PowerOff
        if (has("youtube", "yutub", "yutup") || (t.contains("you") && t.contains("tube"))) return Cmd.YouTube
        if (has("home") || (t.contains("ana") && (t.contains("ekran") || t.contains("sayfa")))) return Cmd.Home
        if (ses) {
            val n = parseNumber(t)
            if (n != null && has("çıkar", "yap", "ayarla", "getir", "al")) return Cmd.VolSet(n)
            if (has("art", "yüksel", "yukarı", "aç", "çoğalt")) return Cmd.VolUp
            if (has("azal", "düşür", "alçal", "kıs", "aşağı")) return Cmd.VolDown
            return Cmd.Unknown
        }
        val n = parseNumber(t)
        if (n != null && n in 0..999) return Cmd.Channel(n)
        val name = t.filter { it !in STOP }.joinToString("")
        return if (name.isNotEmpty() && (has("aç", "geç", "izle", "kanal"))) Cmd.ChannelName(name) else Cmd.Unknown
    }
}
