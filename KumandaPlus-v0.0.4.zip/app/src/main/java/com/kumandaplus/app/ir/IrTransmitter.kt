package com.kumandaplus.app.ir

import android.content.Context
import android.hardware.ConsumerIrManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

sealed class IrResult {
    object Sent : IrResult()
    object NoHardware : IrResult()
    data class Failed(val message: String, val cause: Throwable? = null) : IrResult()
}

/** ConsumerIrManager üzerinden gönderim. Uygulama genelinde tek Mutex: gönderimler sıraya girer, çakışmaz. */
class IrTransmitter(context: Context) {
    private val manager: ConsumerIrManager? =
        context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun hasIrEmitter(): Boolean = manager?.hasIrEmitter() == true

    suspend fun send(p: IrPattern): IrResult {
        val m = manager
        if (m == null || !m.hasIrEmitter()) return IrResult.NoHardware
        return lock.withLock {
            withContext(Dispatchers.IO) {
                try {
                    m.transmit(p.carrierHz, p.pattern)
                    IrResult.Sent
                } catch (t: Throwable) {
                    IrResult.Failed(t.message ?: "IR gönderimi başarısız", t)
                }
            }
        }
    }

    companion object { private val lock = Mutex() }
}
