package com.kumanda.app

import android.content.Context

/**
 * Tuşlar. default = Toshiba için İLK TAHMİN kodları (NEC komut baytı).
 * -1 = atanmamış. Doğru kodlar "Keşif" sekmesinden bulunup atanır.
 */
enum class Key(val label: String, val default: Int = -1) {
    POWER("⏻", 0x12), INPUT("Kaynak", 0x0F), MUTE("🔇", 0x10),
    YOUTUBE("YouTube"), NETFLIX("Netflix"), PRIME("Prime"),
    D1("1", 0x01), D2("2", 0x02), D3("3", 0x03), D4("4", 0x04), D5("5", 0x05),
    D6("6", 0x06), D7("7", 0x07), D8("8", 0x08), D9("9", 0x09), D0("0", 0x00),
    INFO("Bilgi"), EXIT("Çıkış"), GUIDE("Rehber"), SETTINGS("Ayarlar"),
    VOL_UP("Ses +", 0x1A), VOL_DOWN("Ses −", 0x1E),
    CH_UP("Kanal +", 0x1B), CH_DOWN("Kanal −", 0x1F),
    UP("▲"), DOWN("▼"), LEFT("◀"), RIGHT("▶"), OK("OK"),
    BACK("Geri"), HOME("Ana ekran"), MENU("Menü"),
    REW("⏪"), PLAY("▶️"), PAUSE("⏸"), FF("⏩"), STOP("⏹"),
    RED("Kırmızı"), GREEN("Yeşil"), YELLOW("Sarı"), BLUE("Mavi")
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("kumanda", Context.MODE_PRIVATE)

    fun address(c: Context): Int = sp(c).getInt("addr", 0x40)
    fun setAddress(c: Context, v: Int) = sp(c).edit().putInt("addr", v).apply()

    fun code(c: Context, k: Key): Int = sp(c).getInt("code_${k.name}", k.default)
    fun setCode(c: Context, k: Key, v: Int) = sp(c).edit().putInt("code_${k.name}", v).apply()

    fun resetCodes(c: Context) {
        val e = sp(c).edit()
        Key.values().forEach { e.remove("code_${it.name}") }
        e.remove("addr")
        e.apply()
    }

    fun press(c: Context, k: Key): Boolean {
        val cmd = code(c, k)
        if (cmd < 0) return false
        return Ir.send(c, address(c), cmd)
    }

    private const val DEFAULT_CH = "# her satıra: isim=kanal numarası\n# show tv=7"

    fun channels(c: Context): String = sp(c).getString("channels", DEFAULT_CH) ?: DEFAULT_CH
    fun setChannels(c: Context, s: String) = sp(c).edit().putString("channels", s).apply()

    /** normalize edilmiş isim (boşluksuz) -> kanal numarası */
    fun channelMap(c: Context): Map<String, Int> =
        channels(c).lines().mapNotNull { line ->
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("#")) return@mapNotNull null
            val i = l.lastIndexOf('=')
            if (i < 1) return@mapNotNull null
            val name = Commands.norm(l.substring(0, i)).replace(" ", "")
            val num = l.substring(i + 1).trim().toIntOrNull() ?: return@mapNotNull null
            if (name.isEmpty()) null else name to num
        }.toMap()
}
