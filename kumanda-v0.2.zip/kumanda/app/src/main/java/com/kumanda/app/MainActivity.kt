package com.kumanda.app

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🎛️" to "Kumanda", "🎤" to "Ses", "📺" to "TV'ler")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (icon, label) ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Text(icon) },
                    label = { Text(label) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> RemoteScreen()
                1 -> VoiceScreen()
                else -> TvScreen()
            }
        }
    }
}

@Composable
fun KRow(keys: List<Key?>, prof: Profile, onPress: (Key) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        keys.forEach { k ->
            if (k == null) {
                Spacer(Modifier.weight(1f))
            } else {
                val m = Modifier.weight(1f).height(52.dp)
                val pad = PaddingValues(2.dp)
                if (prof.code(k) >= 0) {
                    FilledTonalButton(onClick = { onPress(k) }, modifier = m, contentPadding = pad) {
                        Text(k.label, maxLines = 1, fontSize = 15.sp)
                    }
                } else {
                    OutlinedButton(onClick = { onPress(k) }, modifier = m, contentPadding = pad) {
                        Text(k.label, maxLines = 1, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun RemoteScreen() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val irOk = remember { Ir.available(ctx) }
    val running by VoiceState.running.collectAsState()
    val last by VoiceState.last.collectAsState()
    var ver by remember { mutableIntStateOf(0) }
    val profiles = remember(ver) { Profiles.all(ctx) }
    val prof = remember(ver) { Profiles.active(ctx) }
    var menu by remember { mutableStateOf(false) }

    val perms = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) VoiceService.start(ctx)
        else toast(ctx, "Mikrofon izni gerekli")
    }

    val press: (Key) -> Unit = { k ->
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        val code = prof.code(k)
        if (code < 0) toast(ctx, "${k.label}: kod yok — TV'ler sekmesi > Kod ara")
        else if (!Ir.send(ctx, prof.proto, prof.address, code)) toast(ctx, "IR gönderilemedi")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (!irOk) Text("⚠️ Bu telefonda IR vericisi bulunamadı.", color = MaterialTheme.colorScheme.error)

        Box {
            OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                Text("📺 ${prof.name}  ▾")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                profiles.forEach { p ->
                    DropdownMenuItem(
                        text = { Text(p.name) },
                        onClick = { Profiles.setActive(ctx, p.id); ver++; menu = false }
                    )
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (running) "🎤 Sesli komut açık — \"Hey kumanda…\" de" else "🎤 Sesli komut kapalı")
                if (last.isNotEmpty()) Text(last, style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    if (running) VoiceService.stop(ctx) else launcher.launch(perms)
                }) { Text(if (running) "Durdur" else "Başlat") }
            }
        }

        KRow(listOf(Key.POWER, Key.INPUT, Key.MUTE), prof, press)
        KRow(listOf(Key.YOUTUBE, Key.NETFLIX, Key.PRIME), prof, press)
        KRow(listOf(Key.D1, Key.D2, Key.D3), prof, press)
        KRow(listOf(Key.D4, Key.D5, Key.D6), prof, press)
        KRow(listOf(Key.D7, Key.D8, Key.D9), prof, press)
        KRow(listOf(Key.INFO, Key.D0, Key.EXIT), prof, press)
        KRow(listOf(Key.VOL_UP, Key.CH_UP), prof, press)
        KRow(listOf(Key.VOL_DOWN, Key.CH_DOWN), prof, press)
        KRow(listOf(null, Key.UP, null), prof, press)
        KRow(listOf(Key.LEFT, Key.OK, Key.RIGHT), prof, press)
        KRow(listOf(null, Key.DOWN, null), prof, press)
        KRow(listOf(Key.BACK, Key.HOME, Key.MENU), prof, press)
        KRow(listOf(Key.GUIDE, Key.SETTINGS), prof, press)
        KRow(listOf(Key.REW, Key.PLAY, Key.PAUSE, Key.FF, Key.STOP), prof, press)
        KRow(listOf(Key.RED, Key.GREEN, Key.YELLOW, Key.BLUE), prof, press)
        Text(
            "Çerçeveli (boş) tuşların kodu yok. TV'ler sekmesinden \"Kod ara\" ile öğret.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun VoiceScreen() {
    val ctx = LocalContext.current
    val prof = remember { Profiles.active(ctx) }
    var text by remember {
        mutableStateOf(prof.channels.ifEmpty { "# her satıra: isim=kanal numarası\n# show tv=7" })
    }
    val last by VoiceState.last.collectAsState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Kanal adları — ${prof.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Bu liste sadece aktif TV için geçerli. Her satıra: isim=kanal numarası. Telefonun yazımına göre aynı kanala birden fazla isim ekleyebilirsin (örn. show tv=7 ve şov tv=7).",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = text, onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp)
        )
        Button(onClick = {
            prof.channels = text
            Profiles.upsert(ctx, prof)
            toast(ctx, "Kaydedildi")
        }) { Text("Kaydet") }
        HorizontalDivider()
        Text("Örnek komutlar", fontWeight = FontWeight.Bold)
        Text(
            "• Hey kumanda beşi aç\n" +
                "• Hey kumanda YouTube aç\n" +
                "• Hey kumanda Show TV aç (önce yukarıya ekle)\n" +
                "• Hey kumanda sesi aç / sesi kıs / sesi sustur\n" +
                "• Hey kumanda kanal artır / önceki kanal\n" +
                "• Hey kumanda televizyonu kapat\n" +
                "• Hey kumanda ana ekran, geri, tamam, yukarı, aşağı\n" +
                "• Başka TV için: Hey kumanda <TV adı> sesi aç\n" +
                "• TV değiştir: Hey kumanda <TV adı>'na geç"
        )
        Text("Son komut: $last")
    }
}
