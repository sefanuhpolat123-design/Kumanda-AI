package com.kumandaplus.app.ir

import com.kumandaplus.app.voice.Cmd
import com.kumandaplus.app.voice.CommandParser.parse
import org.junit.Assert.assertEquals
import org.junit.Test

class CommandParserTest {
    @Test fun volume() {
        assertEquals(Cmd.VolUp, parse("sesi artır")); assertEquals(Cmd.VolDown, parse("sesi azalt"))
        assertEquals(Cmd.VolSet(15), parse("sesi on beşe çıkar"))
    }
    @Test fun power() {
        assertEquals(Cmd.PowerOn, parse("televizyonu aç")); assertEquals(Cmd.PowerOff, parse("televizyonu kapat"))
    }
    @Test fun channels() {
        assertEquals(Cmd.Channel(5), parse("beşi aç")); assertEquals(Cmd.Channel(5), parse("beşinci kanala geç"))
        assertEquals(Cmd.Channel(5), parse("kanal beş")); assertEquals(Cmd.Channel(5), parse("beş numaralı kanal"))
        assertEquals(Cmd.Channel(21), parse("yirmi bir"))
    }
    @Test fun names() { assertEquals(Cmd.ChannelName("showtvyi"), parse("show tv'yi aç")) }
    @Test fun youtube() { assertEquals(Cmd.YouTube, parse("youtube'u aç")) }
    @Test fun unknown() { assertEquals(Cmd.Unknown, parse("bugün hava güzel")) }
}
