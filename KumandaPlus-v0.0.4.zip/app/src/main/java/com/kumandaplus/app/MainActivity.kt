package com.kumandaplus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kumandaplus.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    val vm: MainVm = viewModel()
    val settings by vm.settings.collectAsState()
    val dark = when (settings["theme"]) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val scale = settings["font"]?.toFloatOrNull() ?: 1f
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density, d.fontScale * scale)) {
        MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) { Main(vm) }
    }
}

@Composable
private fun Main(vm: MainVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    val msg by vm.message.collectAsState()
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.message.value = null } }
    // İlk kurulum: hiç televizyon yoksa doğrudan "Televizyonlar" ekranına git
    LaunchedEffect(Unit) { if (!vm.hasAnyTv()) tab = 2 }
    val tabs = listOf("Kumanda", "Sesli", "TV'ler", "Kanallar", "Ayarlar")
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t, maxLines = 1) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) { 0 -> RemoteScreen(vm); 1 -> VoiceScreen(vm); 2 -> TvsScreen(vm); 3 -> ChannelsScreen(vm); else -> SettingsScreen(vm) }
        }
    }
}
