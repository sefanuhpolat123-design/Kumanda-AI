package com.kumanda.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ---------------------------------------------------------------- TV listesi

@Composable
fun TvScreen() {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    var editId by remember { mutableStateOf<String?>(null) }
    var scanId by remember { mutableStateOf<String?>(null) }
    var showNew by remember { mutableStateOf(false) }
    val profiles = remember(ver) { Profiles.all(ctx) }
    val activeId = remember(ver) { Profiles.active(ctx).id }

    val sid = scanId
    val eid = editId
    if (sid != null) {
        ScanScreen(sid) { scanId = null; ver++ }
    } else if (eid != null) {
        EditScreen(eid) { editId = null; ver++ }
    } else {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("TV'lerim", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            profiles.forEach { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(p.name + if (p.id == activeId) "   ✅ aktif" else "", fontWeight = FontWeight.Bold)
                        Text(
                            "${p.brand} · ${p.proto.label} · adres 0x%02X".format(p.address) +
                                " · ${p.codes.size}/${Key.values().size} tuş kodlu · " +
                                (if (p.verified) "doğrulandı" else "doğrulanmadı"),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (p.id != activeId) {
                                Button(
                                    onClick = { Profiles.setActive(ctx, p.id); ver++ },
                                    modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                                ) { Text("Aktif yap", fontSize = 13.sp) }
                            }
                            OutlinedButton(
                                onClick = { scanId = p.id },
                                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                            ) { Text("Kod ara", fontSize = 13.sp) }
                            OutlinedButton(
                                onClick = { editId = p.id },
                                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
                            ) { Text("Düzenle", fontSize = 13.sp) }
                        }
                    }
                }
            }
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Yeni TV ekle") }
        }
    }

    if (showNew) {
        var name by remember { mutableStateOf("") }
        var brand by remember { mutableStateOf("Toshiba") }
        var bm by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("Yeni TV") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("Ad (örn. Salon Toshiba)") }, singleLine = true
                    )
                    Box {
                        OutlinedButton(onClick = { bm = true }) { Text("Marka: $brand ▾") }
                        DropdownMenu(expanded = bm, onDismissRequest = { bm = false }) {
                            Presets.brands.forEach { b ->
                                DropdownMenuItem(text = { Text(b) }, onClick = { brand = b; bm = false })
                            }
                        }
                    }
                    Text("Markayı bilmiyorsan \"Diğer\" seç; tüm markalar taranır.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = Profiles.add(ctx, name.trim().ifEmpty { "$brand TV" }, brand)
                    showNew = false
                    ver++
                    scanId = p.id
                }) { Text("Ekle ve kod ara") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Vazgeç") } }
        )
    }
}

// ---------------------------------------------------------------- Düzenle

@Composable
fun EditScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prof = remember { Profiles.all(ctx).first { it.id == id } }
    var name by remember { mutableStateOf(prof.name) }
    var brand by remember { mutableStateOf(prof.brand) }
    var proto by remember { mutableStateOf(prof.proto) }
    var addr by remember { mutableStateOf("%02X".format(prof.address)) }
    var ver by remember { mutableIntStateOf(0) }
    var bm by remember { mutableStateOf(false) }
    var pm by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val tick = ver

    fun addrVal(): Int = (addr.toIntOrNull(16) ?: prof.address) and 0xFF

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Geri") }
        Text("TV'yi düzenle", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("TV adı") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Box {
            OutlinedButton(onClick = { bm = true }) { Text("Marka: $brand ▾") }
            DropdownMenu(expanded = bm, onDismissRequest = { bm = false }) {
                Presets.brands.forEach { b ->
                    DropdownMenuItem(text = { Text(b) }, onClick = { brand = b; bm = false })
                }
            }
        }
        OutlinedButton(onClick = {
            Presets.applyBrand(prof, brand)
            proto = prof.proto
            addr = "%02X".format(prof.address)
            ver++
            toast(ctx, "$brand hazır kodları yüklendi (doğrulanmadı)")
        }) { Text("Marka hazır kodlarını yükle (tuşları sıfırlar)") }
        Box {
            OutlinedButton(onClick = { pm = true }) { Text("Protokol: ${proto.label} ▾") }
            DropdownMenu(expanded = pm, onDismissRequest = { pm = false }) {
                Proto.values().forEach { pr ->
                    DropdownMenuItem(text = { Text(pr.label) }, onClick = { proto = pr; pm = false })
                }
            }
        }
        OutlinedTextField(
            value = addr, onValueChange = { addr = it.take(2).uppercase() },
            label = { Text("Adres (hex)") }, singleLine = true
        )
        Button(onClick = {
            prof.name = name.trim().ifEmpty { prof.name }
            prof.brand = brand
            prof.proto = proto
            prof.address = addrVal()
            Profiles.upsert(ctx, prof)
            toast(ctx, "Kaydedildi")
        }, modifier = Modifier.fillMaxWidth()) { Text("Kaydet") }

        HorizontalDivider()
        Text("Tuş kodları" + "".repeat(tick), fontWeight = FontWeight.Bold)
        Key.values().forEach { k ->
            val code = prof.code(k)
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text("${k.label}  ·  " + if (code < 0) "—" else "0x%02X (%d)".format(code, code))
                TextButton(
                    enabled = code >= 0,
                    onClick = { Ir.send(ctx, proto, addrVal(), code) }
                ) { Text("Test") }
            }
        }
        HorizontalDivider()
        OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) { Text("Bu TV'yi sil") }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Silinsin mi?") },
            text = { Text("${prof.name} ve kanal listesi silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    if (Profiles.delete(ctx, prof.id)) onBack() else toast(ctx, "Son TV silinemez")
                }) { Text("Sil") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Vazgeç") } }
        )
    }
}

// ---------------------------------------------------------------- Kod ara

@Composable
fun ScanScreen(id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prof = remember { Profiles.all(ctx).first { it.id == id } }
    var verified by remember { mutableStateOf(prof.verified) }
    var allBrands by remember { mutableStateOf(prof.brand == "Diğer") }
    var target by remember { mutableStateOf(Presets.LEARN.first()) }
    var idx by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var speed by remember { mutableLongStateOf(400L) }
    var tmenu by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val seen = tick

    val fams = remember(verified, allBrands) {
        if (verified && !allBrands) listOf(Presets.Family(prof.proto, prof.address))
        else Presets.families(if (allBrands) "Diğer" else prof.brand)
    }
    val total = fams.sumOf { it.proto.maxCmd + 1 }

    fun posOf(i: Int): Pair<Presets.Family, Int> {
        var r = i
        for (f in fams) {
            val n = f.proto.maxCmd + 1
            if (r < n) return Pair(f, r)
            r -= n
        }
        val l = fams.last()
        return Pair(l, l.proto.maxCmd)
    }

    fun sendAt(i: Int) {
        val (f, cmd) = posOf(i)
        Ir.send(ctx, f.proto, f.address, cmd)
    }

    fun nextOf(k: Key): Key {
        val l = Presets.LEARN
        return l[(l.indexOf(k) + 1) % l.size]
    }

    LaunchedEffect(fams) {
        idx = 0
        running = false
    }

    LaunchedEffect(running) {
        while (running) {
            sendAt(idx)
            delay(speed)
            if (!running) break
            if (idx < total - 1) idx++ else running = false
        }
    }

    val safeIdx = idx.coerceIn(0, total - 1)
    val (curFam, curCmd) = posOf(safeIdx)
    val savedCode = prof.code(target)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        TextButton(onClick = { running = false; onBack() }) { Text("← Geri") }
        Text("Kod ara — ${prof.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Telefonun üstündeki IR gözünü TV'ye doğrult. Önce aranacak tuşu seç. " +
                "Kayıtlı kod varsa \"Dene\" ile hemen test et; çalışmıyorsa taramayı başlat. " +
                "Tarama kodları sırayla gönderir; TV tepki verince (örn. ses çubuğu çıkınca) Duraklat'a bas, " +
                "◀ Önceki ile geri giderek tepkiyi veren koda dön ve kaydet. " +
                "⚠️ Taramada TV beklenmedik tepkiler verebilir (kapanma, ayar değişikliği).",
            style = MaterialTheme.typography.bodySmall
        )

        Box {
            OutlinedButton(onClick = { tmenu = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Aranan tuş: ${target.label} (${target.name}) ▾" + "".repeat(seen))
            }
            DropdownMenu(expanded = tmenu, onDismissRequest = { tmenu = false }) {
                Key.values().forEach { k ->
                    DropdownMenuItem(
                        text = { Text((if (prof.code(k) >= 0) "✓ " else "   ") + "${k.label} — ${k.name}") },
                        onClick = { target = k; tmenu = false; running = false; idx = 0 }
                    )
                }
            }
        }

        if (savedCode >= 0) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Kayıtlı kod: 0x%02X (%d)".format(savedCode, savedCode))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            Ir.send(ctx, prof.proto, prof.address, savedCode)
                        }) { Text("Dene") }
                        Button(onClick = {
                            prof.verified = true
                            Profiles.upsert(ctx, prof)
                            verified = true
                            target = nextOf(target)
                            tick++
                            toast(ctx, "Onaylandı")
                        }) { Text("Çalışıyor ✔ sonraki") }
                    }
                }
            }
        }

        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(checked = allBrands, onCheckedChange = { allBrands = it })
            Spacer(Modifier.width(8.dp))
            Text("Tüm markalarda ara")
        }

        Text(
            "${curFam.label}\nKomut: $curCmd (0x%02X)   ·   ${safeIdx + 1}/$total".format(curCmd),
            fontWeight = FontWeight.Bold
        )
        LinearProgressIndicator(progress = { (safeIdx + 1).toFloat() / total }, modifier = Modifier.fillMaxWidth())

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(
                onClick = { running = !running },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text(if (running) "⏸ Duraklat" else "▶ Başlat", fontSize = 13.sp) }
            OutlinedButton(
                onClick = { running = false; idx = (safeIdx - 1).coerceAtLeast(0); sendAt(idx) },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text("◀ Önceki", fontSize = 13.sp) }
            OutlinedButton(
                onClick = { running = false; idx = (safeIdx + 1).coerceAtMost(total - 1); sendAt(idx) },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text("Sonraki ▶", fontSize = 13.sp) }
            OutlinedButton(
                onClick = { sendAt(safeIdx) },
                modifier = Modifier.weight(1f), contentPadding = PaddingValues(4.dp)
            ) { Text("↻", fontSize = 13.sp) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Hızlı 0.3s" to 300L, "Orta 0.6s" to 600L, "Yavaş 1s" to 1000L).forEach { (l, ms) ->
                if (speed == ms) {
                    FilledTonalButton(
                        onClick = { speed = ms },
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)
                    ) { Text(l, fontSize = 12.sp) }
                } else {
                    OutlinedButton(
                        onClick = { speed = ms },
                        modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)
                    ) { Text(l, fontSize = 12.sp) }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("−10" to -10, "+10" to 10).forEach { (l, d) ->
                OutlinedButton(
                    onClick = { running = false; idx = (safeIdx + d).coerceIn(0, total - 1); sendAt(idx) },
                    modifier = Modifier.weight(1f)
                ) { Text(l) }
            }
        }

        Button(
            onClick = {
                running = false
                if (curFam.proto != prof.proto || curFam.address != prof.address) prof.codes.clear()
                prof.proto = curFam.proto
                prof.address = curFam.address
                prof.codes[target.name] = curCmd
                prof.verified = true
                Profiles.upsert(ctx, prof)
                verified = true
                val done = target
                target = nextOf(target)
                idx = 0
                tick++
                toast(ctx, "${done.label} = $curCmd kaydedildi")
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("✔ ${target.label} = bu komut (kaydet)") }
        OutlinedButton(
            onClick = { running = false; target = nextOf(target); idx = 0 },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Bu tuşu atla ▸") }
    }
}
