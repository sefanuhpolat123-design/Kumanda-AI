package com.kumandaplus.app

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/** IR sender backed only by documented, source-attributed profiles. */
class IrController(private val context: Context) {
    private val manager = context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    private val queue = Executors.newSingleThreadExecutor()

    fun hasEmitter(): Boolean = manager?.hasIrEmitter() == true

    fun send(key: String) {
        val profile = IrLibrary.selectedProfile(context)
        val code = profile?.commands?.get(key)
        if (manager?.hasIrEmitter() != true || code == null) {
            Handler(Looper.getMainLooper()).post {
                val message = if (manager?.hasIrEmitter() != true) "Bu telefonda IR vericisi bulunamadı." else "Seçili TV profili için $key kodu bulunamadı. Başka profil deneyin veya güncelleme bekleyin."
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
            return
        }
        queue.execute {
            try { manager.transmit(38000, code.timings()) }
            catch (_: Exception) { Handler(Looper.getMainLooper()).post { Toast.makeText(context, "IR sinyali gönderilemedi.", Toast.LENGTH_SHORT).show() } }
        }
    }
}

data class IrCommand(val protocol: String, val address: Int, val command: Int) {
    fun timings(): IntArray {
        val out = ArrayList<Int>()
        val samsung = protocol.equals("Samsung32", true)
        out += if (samsung) listOf(4500, 4500) else listOf(9000, 4500)
        val bytes = intArrayOf(address and 0xff, (address.inv()) and 0xff, command and 0xff, (command.inv()) and 0xff)
        for (b in bytes) for (bit in 0..7) {
            out += 560
            out += if (((b shr bit) and 1) == 1) 1690 else 560
        }
        out += 560
        return out.toIntArray()
    }
}

data class IrProfile(val id: String, val brand: String, val model: String, val protocol: String, val commands: Map<String, IrCommand>)

object IrLibrary {
    private val profiles = listOf(
        IrProfile("lg_unknown_nec", "LG", "LG TV (bilinmeyen model; IRDB profili)", "NEC", mapOf(
            "POWER" to IrCommand("NEC", 0x04, 0x08), "MUTE" to IrCommand("NEC", 0x04, 0x09),
            "VOL_UP" to IrCommand("NEC", 0x04, 0x02), "CH_UP" to IrCommand("NEC", 0x04, 0x00),
            "VOL_DOWN" to IrCommand("NEC", 0x04, 0x03), "CH_DOWN" to IrCommand("NEC", 0x04, 0x01)
        )),
        IrProfile("samsung_tv_2", "Samsung", "Samsung TV 2", "Samsung32", mapOf(
            "POWER" to IrCommand("Samsung32", 0x07, 0x02), "UP" to IrCommand("Samsung32", 0x07, 0x60),
            "DOWN" to IrCommand("Samsung32", 0x07, 0x61), "LEFT" to IrCommand("Samsung32", 0x07, 0x65),
            "RIGHT" to IrCommand("Samsung32", 0x07, 0x62), "BACK" to IrCommand("Samsung32", 0x07, 0x58),
            "VOL_UP" to IrCommand("Samsung32", 0x07, 0x07), "VOL_DOWN" to IrCommand("Samsung32", 0x07, 0x0B),
            "HDMI" to IrCommand("Samsung32", 0x07, 0x01), "OK" to IrCommand("Samsung32", 0x07, 0x68),
            "MUTE" to IrCommand("Samsung32", 0x07, 0x0F), "HOME" to IrCommand("Samsung32", 0x07, 0x79)
        ))
    )

    fun profilesForBrand(brand: String): List<IrProfile> = profiles.filter { it.brand.equals(brand, true) }

    fun selectedProfile(context: Context): IrProfile? {
        val prefs = context.getSharedPreferences("kumanda_plus", Context.MODE_PRIVATE)
        val selected = prefs.getLong("selected_tv", -1L)
        val arr = JSONArray(prefs.getString("tvs", "[]"))
        for (i in 0 until arr.length()) {
            val item: JSONObject = arr.getJSONObject(i)
            if (item.optLong("id") == selected) return profilesForBrand(item.optString("brand")).firstOrNull()
        }
        return null
    }
}
