package com.kumandaplus.app.ir

import org.junit.Assert.*
import org.junit.Test

class NecEncoderTest {
    @Test fun frameHas67Durations() {
        val p = NecEncoder.encode(0x04, 0x08)
        assertEquals(68, p.pattern.size)
        assertEquals(9000, p.pattern[0]); assertEquals(4500, p.pattern[1])
        assertEquals(38_000, p.carrierHz)
    }
    @Test fun lsbFirstBits() {
        // adres 0x01 -> ilk bit 1 => ilk boşluk 1690
        val p = NecEncoder.encode(0x01, 0x00)
        assertEquals(1690, p.pattern[3]); assertEquals(560, p.pattern[5])
    }
    @Test(expected = IllegalArgumentException::class) fun badCommandRejected() { NecEncoder.encode(1, 300) }
}
