# Kumanda+ v0.0.3

This build includes two source-attributed starter IR profiles (LG unknown-model NEC and Samsung TV 2 Samsung32) transcribed from the CC0 Flipper-IRDB repository. The app selects a starter profile by the selected TV brand. Unsupported brands/keys intentionally return no signal rather than sending fabricated codes.

## IR data provenance
See `app/src/main/assets/ir-library/SOURCES.md`. Upstream repository: https://github.com/Lucaslhm/Flipper-IRDB

## Important limitations
- This is a small starter library, not a comprehensive 20+ brand database.
- LG profile has six commands; Samsung profile has twelve commands. Digit and YouTube commands are not present in these source files.
- The current voice service is still a notification-only placeholder. Offline wake-word and Turkish speech recognition are not implemented in this build.
- IR is one-way; successful transmission cannot be verified by the phone.
- Profile compatibility must be tested against the actual television.

Build with JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2.
