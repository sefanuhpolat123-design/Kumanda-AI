# Kumanda+ Android proje paketi — v0.0.1

Bu depo Android 10+ (API 29+) için Kotlin + Jetpack Compose başlangıç projesidir. İnternet izni tanımlı değildir. Uygulama portre kullanımına göre hazırlanmıştır.

## GitHub'da her zaman en güncel ZIP'i APK'ya çevirme

1. İlk kurulumda bu ZIP'i açın ve içindeki proje dosyalarını GitHub deposunun kök dizinine yükleyin. `.github/workflows/android.yml` dosyasının da depoda bulunduğundan emin olun.
2. Commit edip `main` veya `master` dalına gönderin. Bu ilk gönderim workflow'u çalıştırır.
3. Daha sonraki sürümlerde yeni kaynak ZIP'ini GitHub deposunda `source-zips/latest.zip` adıyla yükleyin (önceki `latest.zip` dosyasının üzerine yazın) ve commit/push yapın.
4. Workflow, `source-zips/latest.zip` varsa onu açıp içindeki projeyi derler. Bu dosya yoksa depo kökündeki projeyi derler.
5. GitHub > Actions > **Kumanda+ Android APK** > tamamlanan işlem > **Artifacts** bölümünden `KumandaPlus-debug-apk` dosyasını indirin.
6. İsterseniz Actions içinden **Run workflow** ile de en son gönderilmiş ZIP'i yeniden derletebilirsiniz.

Böylece her yeni `latest.zip` gönderiminde APK otomatik üretilir. ZIP'in içindeki en üst klasör adı önemli değildir; workflow `settings.gradle.kts` dosyasını bulup proje kökünü tespit eder.

## Şu anki uygulama kapsamı

- TV ekleme ve marka seçme ekranı; birden fazla TV profilini yerel olarak saklama ve seçili TV'yi hatırlama.
- Kumanda ekranında güç, ses, rakam, YouTube ve Home tuşları için arayüz.
- IR gönderim kuyruğu ve Android `ConsumerIrManager` entegrasyonu.
- Dinleme hizmetini başlatıp durdurmaya yönelik foreground-service iskeleti ve bildirim.
- Tema ve yazı boyutu tercih ekranı.

## Önemli: henüz tamamlanmamış parçalar

Bu ZIP, istenen ürünün tamamlanmış sürümü değildir; derlenebilir bir başlangıç iskeletidir. Bilerek sahte IR sinyali eklenmemiştir. `IrLibrary.profileFor()` şu an boş döner. Bu nedenle marka seçimi tek başına TV'yi çalıştırmaz; doğrulanmış IR profil verileri, sırayla deneme/test ekranı ve profil kaydetme akışı henüz eklenmelidir.

Aynı şekilde `VoiceListeningService` yalnızca foreground-service ve bildirim iskeletidir. "Hey Kumanda" yerel uyandırma modeli ve çevrimdışı Türkçe konuşma tanıma modeli pakete dahil değildir; bu nedenle arka planda sesli komut henüz çalışmaz. Bu modelleri ve Android'in arka plan mikrofon kısıtlamalarını doğrulamadan sesli özelliği çalışıyor olarak sunmak doğru olmaz.

Kanal listesi düzenleme, hazır Türkiye kanal listesi, profil eşleştirme/test ekranı, IR protokol veritabanı, gerçek çevrimdışı ses tanıma, komut çözümleme ve otomatik testler sonraki geliştirme adımlarıdır.

## Geliştirme notları

- Uygulama kimliği: `com.kumandaplus.app`
- Sürüm: `0.0.1` (versionCode 1)
- Minimum Android: 10 (API 29)
- IR gönderim frekansı: başlangıçta 38 kHz; her profil için doğrulanmalıdır.
- `app/src/main/java/com/kumandaplus/app/IrController.kt` içindeki `IrLibrary` nesnesine doğrulanmış ham IR örüntüleri eklenmelidir.
