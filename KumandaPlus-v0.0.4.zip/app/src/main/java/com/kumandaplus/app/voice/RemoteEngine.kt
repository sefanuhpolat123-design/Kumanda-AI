package com.kumandaplus.app.voice

import android.content.Context
import com.kumandaplus.app.data.*
import com.kumandaplus.app.ir.*
import kotlinx.coroutines.delay

/** Komutu seçili televizyonun profiline göre uygular. Belirsizse işlem yapmaz. */
class RemoteEngine(ctx: Context) {
    private val dao = AppDb.get(ctx).dao()
    private val ir = IrTransmitter(ctx)
    val hasIr get() = ir.hasIrEmitter()
    var lastError: String? = null

    suspend fun run(cmd: Cmd): String {
        val tv = dao.currentOnce() ?: return "Seçili televizyon yok."
        val keys = dao.keysOnce(tv.id).associate { it.keyName to it.command }
        suspend fun send(k: RKey): String {
            val c = keys[k.name] ?: return "${k.label} kodu kayıtlı değil (Kumanda ekranında tuşu basılı tutup öğret)."
            return when (val r = ir.send(NecEncoder.encode(tv.address, c, tv.carrierHz))) {
                IrResult.Sent -> "Tamam: ${k.label}"
                IrResult.NoHardware -> "Bu telefonda IR vericisi yok."
                is IrResult.Failed -> { lastError = r.cause?.stackTraceToString() ?: r.message; "Gönderim hatası: ${r.message}" }
            }
        }
        suspend fun channel(n: Int): String {
            val digits = n.toString().map { RKey.valueOf("D$it") }
            digits.firstOrNull { it.name !in keys }?.let { return "${it.label} rakamı öğrenilmemiş." }
            var last = ""
            for (d in digits) { last = send(d); if (!last.startsWith("Tamam")) return last; delay(400) }
            return "Kanal $n açıldı."
        }
        return when (cmd) {
            Cmd.PowerOn -> if (RKey.POWER_ON.name in keys) send(RKey.POWER_ON) else send(RKey.POWER)
            Cmd.PowerOff -> if (RKey.POWER_OFF.name in keys) send(RKey.POWER_OFF) else send(RKey.POWER)
            Cmd.VolUp -> send(RKey.VOL_UP); Cmd.VolDown -> send(RKey.VOL_DOWN); Cmd.Mute -> send(RKey.MUTE)
            Cmd.Home -> send(RKey.HOME)
            Cmd.YouTube -> if (RKey.YOUTUBE.name in keys) send(RKey.YOUTUBE) else "Bu kumanda profilinde YouTube tuşu yok."
            is Cmd.VolSet -> "Mutlak ses seviyesi IR ile okunamaz; 'sesi artır/azalt' kullan."
            is Cmd.Channel -> channel(cmd.number)
            is Cmd.ChannelName -> {
                val hits = dao.channelsOnce(tv.id).filter {
                    val c = CommandParser.compact(it.name)
                    c.isNotEmpty() && cmd.compact.startsWith(c) && cmd.compact.length - c.length <= 3
                }
                if (hits.size == 1) channel(hits[0].number)
                else if (hits.isEmpty()) "Kanal bulunamadı: ${cmd.compact}" else "Kanal adı belirsiz, işlem yapılmadı."
            }
            Cmd.Unknown -> "Komut anlaşılmadı."
        }
    }
}
