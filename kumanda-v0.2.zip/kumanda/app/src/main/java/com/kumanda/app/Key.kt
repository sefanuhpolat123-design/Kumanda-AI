package com.kumanda.app

/** Kumanda tuşları. Sıra, "Kod ara" sihirbazındaki öğrenme sırasıdır. */
enum class Key(val label: String) {
    VOL_UP("Ses +"), VOL_DOWN("Ses −"), MUTE("🔇"), POWER("⏻"),
    CH_UP("Kanal +"), CH_DOWN("Kanal −"),
    D1("1"), D2("2"), D3("3"), D4("4"), D5("5"), D6("6"), D7("7"), D8("8"), D9("9"), D0("0"),
    YOUTUBE("YouTube"), NETFLIX("Netflix"), PRIME("Prime"), INPUT("Kaynak"),
    UP("▲"), DOWN("▼"), LEFT("◀"), RIGHT("▶"), OK("OK"),
    BACK("Geri"), HOME("Ana ekran"), MENU("Menü"), INFO("Bilgi"), EXIT("Çıkış"),
    GUIDE("Rehber"), SETTINGS("Ayarlar"),
    PLAY("▶️"), PAUSE("⏸"), REW("⏪"), FF("⏩"), STOP("⏹"),
    RED("Kırmızı"), GREEN("Yeşil"), YELLOW("Sarı"), BLUE("Mavi")
}
