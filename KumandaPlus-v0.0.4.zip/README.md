# Kumanda+ v0.0.4

Çalışanlar (kod yazıldı; derleme GitHub Actions'ta doğrulanacak):
- NEC IR gönderimi (ConsumerIrManager, uygulama genelinde sıralı), Room (TV, tuş kodu, kanal, ayarlar)
- Çoklu TV, son seçilen TV, silerken onay, TV başına kanal listesi, tuş öğrenme (0-255 tarama)
- Toshiba profili (doğrulanmış): NEC1 cihaz 64; Güç toggle 18, AÇ 126, KAPAT 127. Ses/rakam/YouTube: uygulamada öğretilir.
- Hey Kumanda: ön plan mikrofon servisi + Vosk çevrimdışı Türkçe tanıma. Model: vosk-model-small-tr-0.3 (35 MB, Apache-2.0),
  GitHub Actions derlemesi sırasında indirilip APK'ya gömülür. Ses kaydedilmez/gönderilmez. Yeniden başlatmada otomatik açılmaz.
- Türkçe komut çözümleyici (birim testli), ayarlar (tema, yazı boyutu, uyandırma kelimesi), hata kopyalama.

Sınırlar: uyandırma, düşük güçlü özel model değil; Vosk'un kelime kısıtlı tanıyıcısıdır (pil tüketimi daha yüksek, yanlış tetik olabilir).
Telefon üreticisi (MIUI) arka plan mikrofonunu kısıtlayabilir: pil tasarrufunu "kısıtlama yok" yap.
"Sesi 15'e çıkar": IR ile mutlak ses okunamadığı için uygulanmaz. Kanal adı eşleşmesi: tanıyıcının yazımına bağlıdır.
Henüz yok: IRDB ile diğer marka profilleri, klavye/mouse (ilk sürüme dahil değil). Fiziksel IR ve gerçek mikrofon testi yapılmadı.
Derleme: depoya yükle -> Actions -> Build APK -> Artifacts -> KumandaPlus-debug.apk
