package com.kumanda.app

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("🎛️" to "Kumanda", "🎤" to "Ses", "🔍" to "Keşif")
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, (icon, label) ->
                NavigationBarItem(
                    selected = tab == i,
                    onClick = { tab = i },
                    icon = { Text(icon) },
                    label = { Text(label) }
                )
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> RemoteScreen()
                1 -> VoiceScreen()
                else -> DiscoverScreen()
            }
        }
    }
}

@Composable
fun KRow(keys: List<Key?>, onPress: (Key) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        keys.forEach { k ->
            if (k == null) {
                Spacer(Modifier.weight(1f))
            } else {
                FilledTonalButton(
                    onClick = { onPress(k) },
                    modifier = Modifier.weight(1f).height(52.dp),
                    contentPadding = PaddingValues(2.dp)
                ) { Text(k.label, maxLines = 1, fontSize = 15.sp) }
            }
        }
    }
}

@Composable
fun RemoteScreen() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val irOk = remember { Ir.available(ctx) }
    val running by VoiceState.running.collectAsState()
    val last by VoiceState.last.collectAsState()

    val perms = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) VoiceService.start(ctx)
        else toast(ctx, "Mikrofon izni gerekli")
    }

    val press: (Key) -> Unit = { k ->
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (Store.code(ctx, k) < 0) toast(ctx, "${k.label}: kod atanmamış — Keşif sekmesinden ata")
        else if (!Store.press(ctx, k)) toast(ctx, "IR gönderilemedi")
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (!irOk) Text("⚠️ Bu telefonda IR vericisi bulunamadı.", color = MaterialTheme.colorScheme.error)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (running) "🎤 Sesli komut açık — \"Hey kumanda…\" de" else "🎤 Sesli komut kapalı")
                if (last.isNotEmpty()) Text(last, style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    if (running) VoiceService.stop(ctx) else launcher.launch(perms)
                }) { Text(if (running) "Durdur" else "Başlat") }
            }
        }

        KRow(listOf(Key.POWER, Key.INPUT, Key.MUTE), press)
        KRow(listOf(Key.YOUTUBE, Key.NETFLIX, Key.PRIME), press)
        KRow(listOf(Key.D1, Key.D2, Key.D3), press)
        KRow(listOf(Key.D4, Key.D5, Key.D6), press)
        KRow(listOf(Key.D7, Key.D8, Key.D9), press)
        KRow(listOf(Key.INFO, Key.D0, Key.EXIT), press)
        KRow(listOf(Key.VOL_UP, Key.CH_UP), press)
        KRow(listOf(Key.VOL_DOWN, Key.CH_DOWN), press)
        KRow(listOf(null, Key.UP, null), press)
        KRow(listOf(Key.LEFT, Key.OK, Key.RIGHT), press)
        KRow(listOf(null, Key.DOWN, null), press)
        KRow(listOf(Key.BACK, Key.HOME, Key.MENU), press)
        KRow(listOf(Key.GUIDE, Key.SETTINGS), press)
        KRow(listOf(Key.REW, Key.PLAY, Key.PAUSE, Key.FF, Key.STOP), press)
        KRow(listOf(Key.RED, Key.GREEN, Key.YELLOW, Key.BLUE), press)
    }
}

@Composable
fun VoiceScreen() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf(Store.channels(ctx)) }
    val last by VoiceState.last.collectAsState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Kanal adları", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Her satıra: isim=kanal numarası. Telefonun yazımına göre aynı kanala birden fazla isim ekleyebilirsin (örn. show tv=7 ve şov tv=7).",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = text, onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp)
        )
        Button(onClick = { Store.setChannels(ctx, text); toast(ctx, "Kaydedildi") }) { Text("Kaydet") }
        HorizontalDivider()
        Text("Örnek komutlar", fontWeight = FontWeight.Bold)
        Text(
            "• Hey kumanda beşi aç\n" +
                "• Hey kumanda YouTube aç\n" +
                "• Hey kumanda Show TV aç (önce yukarıya ekle)\n" +
                "• Hey kumanda sesi aç / sesi kıs / sesi sustur\n" +
                "• Hey kumanda kanal artır / önceki kanal\n" +
                "• Hey kumanda televizyonu kapat\n" +
                "• Hey kumanda ana ekran, geri, tamam, yukarı, aşağı"
        )
        Text("Son komut: $last")
    }
}

@Composable
fun DiscoverScreen() {
    val ctx = LocalContext.current
    var addr by remember { mutableStateOf("%02X".format(Store.address(ctx))) }
    var cmd by remember { mutableIntStateOf(0) }
    var auto by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf(Key.YOUTUBE) }
    var menu by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    fun a(): Int = (addr.toIntOrNull(16) ?: 0x40) and 0xFF

    LaunchedEffect(auto) {
        while (auto) {
            Ir.send(ctx, a(), cmd)
            delay(1500)
            if (!auto) break
            if (cmd < 255) cmd++ else auto = false
        }
    }

    val assigned = remember(pick, tick) { Store.code(ctx, pick) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Kod keşfi", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Telefonun IR vericisini TV'ye doğrult. Komut gönder; TV tepki verirse (örn. YouTube açılırsa) aşağıdan tuşu seçip \"Bu komutu ata\"ya bas.\n" +
                "⚠️ Otomatik taramada TV beklenmedik tepkiler verebilir (kapanma, ayar değişikliği). TV'ye bakarak yap.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = addr, onValueChange = { addr = it.take(2).uppercase() },
            label = { Text("Adres (hex, Toshiba genelde 40)") }, singleLine = true
        )
        Text("Komut: 0x%02X  (%d)".format(cmd, cmd), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("−10" to -10, "−1" to -1, "+1" to 1, "+10" to 10).forEach { (l, d) ->
                OutlinedButton(
                    onClick = { cmd = (cmd + d).coerceIn(0, 255) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(2.dp)
                ) { Text(l) }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { Ir.send(ctx, a(), cmd) }, modifier = Modifier.weight(1f)) { Text("Gönder") }
            Button(onClick = { auto = !auto }, modifier = Modifier.weight(1f)) {
                Text(if (auto) "Taramayı durdur" else "Otomatik tara")
            }
        }
        HorizontalDivider()
        Box {
            OutlinedButton(onClick = { menu = true }) { Text("Tuş: ${pick.name} (${pick.label})") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                Key.values().forEach { k ->
                    DropdownMenuItem(
                        text = { Text("${k.name} — ${k.label}") },
                        onClick = { pick = k; menu = false }
                    )
                }
            }
        }
        Text("Şu an atanmış kod: " + if (assigned < 0) "yok" else "0x%02X".format(assigned))
        Button(
            onClick = {
                Store.setAddress(ctx, a())
                Store.setCode(ctx, pick, cmd)
                tick++
                val hex = "%02X".format(cmd)
                toast(ctx, "${pick.name} = 0x$hex atandı")
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Bu komutu ata") }
        OutlinedButton(
            onClick = {
                Store.resetCodes(ctx)
                addr = "%02X".format(Store.address(ctx))
                tick++
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Varsayılan kodlara dön") }
    }
}
