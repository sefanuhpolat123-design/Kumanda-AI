package com.kumanda.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Bir kumanda profili: ad, protokol, adres, tuş kodları ve kanal listesi. */
class Profile(
    val id: String,
    var name: String,
    var brand: String,
    var proto: Proto,
    var address: Int,
    val codes: MutableMap<String, Int>,
    var channels: String,
    var verified: Boolean = false
) {
    fun code(k: Key): Int = codes[k.name] ?: -1

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("name", name)
        o.put("brand", brand)
        o.put("proto", proto.name)
        o.put("addr", address)
        o.put("channels", channels)
        o.put("verified", verified)
        val co = JSONObject()
        codes.forEach { (k, v) -> co.put(k, v) }
        o.put("codes", co)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Profile {
            val codes = mutableMapOf<String, Int>()
            val co = o.optJSONObject("codes")
            if (co != null) {
                val it = co.keys()
                while (it.hasNext()) {
                    val k = it.next()
                    codes[k] = co.getInt(k)
                }
            }
            val proto = try { Proto.valueOf(o.getString("proto")) } catch (e: Exception) { Proto.NEC }
            return Profile(
                o.getString("id"), o.getString("name"), o.optString("brand", "Diğer"),
                proto, o.optInt("addr", 0x40), codes, o.optString("channels", ""),
                o.optBoolean("verified", false)
            )
        }
    }
}

/** Hazır marka bilgileri. Kodlar hazır başlangıçtır; her TV'de "Kod ara" ile doğrulanmalı. */
object Presets {
    val brands = listOf("Toshiba", "Vestel", "Samsung", "LG", "Sony", "Philips", "Diğer")
    val LEARN: List<Key> = Key.values().toList()

    class Family(val proto: Proto, val address: Int) {
        val label: String get() = "${proto.label} · adres 0x%02X".format(address)
    }

    fun families(brand: String): List<Family> = when (brand) {
        "Toshiba" -> listOf(Family(Proto.NEC, 0x40))
        "Vestel" -> listOf(Family(Proto.RC5, 0), Family(Proto.NEC, 0x00), Family(Proto.NEC, 0x40))
        "Samsung" -> listOf(Family(Proto.SAMSUNG, 0x07))
        "LG" -> listOf(Family(Proto.NEC, 0x04))
        "Sony" -> listOf(Family(Proto.SONY, 1))
        "Philips" -> listOf(Family(Proto.RC5, 0))
        else -> listOf(
            Family(Proto.NEC, 0x40), Family(Proto.NEC, 0x04), Family(Proto.SAMSUNG, 0x07),
            Family(Proto.RC5, 0), Family(Proto.SONY, 1), Family(Proto.NEC, 0x00)
        )
    }

    private val DK = listOf(Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6, Key.D7, Key.D8, Key.D9)
    private fun dig(vararg v: Int): Map<Key, Int> = DK.zip(v.toList()).toMap()

    fun codes(brand: String): Map<Key, Int> = when (brand) {
        "Toshiba" -> mapOf(
            Key.POWER to 0x12, Key.INPUT to 0x0F, Key.MUTE to 0x10,
            Key.VOL_UP to 0x1A, Key.VOL_DOWN to 0x1E, Key.CH_UP to 0x1B, Key.CH_DOWN to 0x1F
        ) + dig(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        "Vestel", "Philips" -> mapOf(
            Key.POWER to 12, Key.MUTE to 13, Key.VOL_UP to 16, Key.VOL_DOWN to 17,
            Key.CH_UP to 32, Key.CH_DOWN to 33
        ) + dig(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
        "Samsung" -> mapOf(
            Key.POWER to 0x02, Key.INPUT to 0x01, Key.MUTE to 0x0F,
            Key.VOL_UP to 0x07, Key.VOL_DOWN to 0x0B, Key.CH_UP to 0x12, Key.CH_DOWN to 0x10,
            Key.MENU to 0x1A, Key.INFO to 0x1F, Key.EXIT to 0x2D,
            Key.UP to 0x60, Key.DOWN to 0x61, Key.LEFT to 0x65, Key.RIGHT to 0x62,
            Key.OK to 0x68, Key.BACK to 0x58, Key.HOME to 0x79
        ) + dig(0x11, 0x04, 0x05, 0x06, 0x08, 0x09, 0x0A, 0x0C, 0x0D, 0x0E)
        "LG" -> mapOf(
            Key.POWER to 0x08, Key.INPUT to 0x0B, Key.MUTE to 0x09,
            Key.VOL_UP to 0x02, Key.VOL_DOWN to 0x03, Key.CH_UP to 0x00, Key.CH_DOWN to 0x01,
            Key.UP to 0x40, Key.DOWN to 0x41, Key.LEFT to 0x07, Key.RIGHT to 0x06,
            Key.OK to 0x44, Key.BACK to 0x28, Key.HOME to 0x7C, Key.MENU to 0x43,
            Key.INFO to 0xAA, Key.EXIT to 0x5B
        ) + dig(0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19)
        "Sony" -> mapOf(
            Key.POWER to 21, Key.MUTE to 20, Key.VOL_UP to 18, Key.VOL_DOWN to 19,
            Key.CH_UP to 16, Key.CH_DOWN to 17, Key.INPUT to 37,
            Key.UP to 116, Key.DOWN to 117, Key.LEFT to 52, Key.RIGHT to 51,
            Key.OK to 101, Key.BACK to 8, Key.HOME to 96, Key.INFO to 58
        ) + dig(9, 0, 1, 2, 3, 4, 5, 6, 7, 8)
        else -> emptyMap()
    }

    fun applyBrand(p: Profile, brand: String) {
        val f = families(brand).first()
        p.brand = brand
        p.proto = f.proto
        p.address = f.address
        p.codes.clear()
        codes(brand).forEach { (k, v) -> p.codes[k.name] = v }
        p.verified = false
    }
}

object Profiles {
    private fun sp(c: Context) = c.getSharedPreferences("kumanda2", Context.MODE_PRIVATE)

    private fun load(c: Context): List<Profile> {
        val s = sp(c).getString("profiles", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { Profile.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun saveAll(c: Context, l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp(c).edit().putString("profiles", a.toString()).apply()
    }

    fun newProfile(name: String, brand: String): Profile {
        val p = Profile(UUID.randomUUID().toString(), name, brand, Proto.NEC, 0x40, mutableMapOf(), "")
        Presets.applyBrand(p, brand)
        return p
    }

    fun all(c: Context): List<Profile> {
        val l = load(c)
        if (l.isNotEmpty()) return l
        val p = newProfile("Toshiba TV", "Toshiba")
        saveAll(c, listOf(p))
        setActive(c, p.id)
        return listOf(p)
    }

    fun add(c: Context, name: String, brand: String): Profile {
        val p = newProfile(name, brand)
        saveAll(c, all(c) + p)
        return p
    }

    fun upsert(c: Context, p: Profile) {
        val l = all(c).toMutableList()
        val i = l.indexOfFirst { it.id == p.id }
        if (i >= 0) l[i] = p else l.add(p)
        saveAll(c, l)
    }

    fun delete(c: Context, id: String): Boolean {
        val l = all(c)
        if (l.size <= 1) return false
        val rest = l.filter { it.id != id }
        saveAll(c, rest)
        if (sp(c).getString("active", null) == id) setActive(c, rest.first().id)
        return true
    }

    fun active(c: Context): Profile {
        val l = all(c)
        val id = sp(c).getString("active", null)
        return l.firstOrNull { it.id == id } ?: l.first()
    }

    fun setActive(c: Context, id: String) {
        sp(c).edit().putString("active", id).apply()
    }

    /** normalize edilmiş isim (boşluksuz) -> kanal numarası */
    fun channelMap(p: Profile): Map<String, Int> =
        p.channels.lines().mapNotNull { line ->
            val l = line.trim()
            if (l.isEmpty() || l.startsWith("#")) return@mapNotNull null
            val i = l.lastIndexOf('=')
            if (i < 1) return@mapNotNull null
            val name = Commands.norm(l.substring(0, i)).replace(" ", "")
            val num = l.substring(i + 1).trim().toIntOrNull() ?: return@mapNotNull null
            if (name.isEmpty()) null else name to num
        }.toMap()
}
