# Kumanda (Toshiba IR + sesli komut)

## APK nasıl alınır
1. GitHub'da yeni repo aç, bu klasördeki tüm dosyaları yükle.
   - `.github/workflows/build.yml` dosyasını web'den elle oluştur: "Add file > Create new file",
     adı `.github/workflows/build.yml`, içeriği `github-workflow-build.yml` dosyasından yapıştır.
2. Repo > Actions > "Build APK" > Run workflow (push'ta da otomatik çalışır).
3. Bitince çalıştırmanın altındaki "kumanda-apk" dosyasını indir, zip'ten çıkan `app-debug.apk`'yı telefona kur.

## İlk kullanım
1. **Keşif** sekmesi: Adres 40 ile başla. TV'ye doğrultup komutu −/+ ile gez, "Gönder"e bas.
   TV tepki verince tuşu seçip "Bu komutu ata". Önce temel tuşları (güç, ses, kanal, rakamlar) test et,
   sonra YouTube/Netflix ve yön tuşlarını bul. (Varsayılan kodlar TAHMİNDİR.)
2. **Ses** sekmesi: kanal adlarını ekle (show tv=7 gibi).
3. **Kumanda** sekmesi: "Başlat" > izin ver > "Hey kumanda beşi aç".

## Xiaomi/Redmi ayarı
Ayarlar > Uygulamalar > Kumanda > Otomatik başlat: açık, Pil tasarrufu: Kısıtlama yok.
