package com.kumandaplus.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Foreground-service shell. Actual offline wake-word + ASR model is not bundled in this starter package. */
class VoiceListeningService : Service() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Kumanda+ sesli dinleme", NotificationManager.IMPORTANCE_LOW))
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            .setContentTitle("Kumanda+ dinlemede").setContentText("Uyandırma kelimesi motoru henüz eklenmedi.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("Kumanda+ dinlemede").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(41, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val CHANNEL = "kumanda_voice" }
}
