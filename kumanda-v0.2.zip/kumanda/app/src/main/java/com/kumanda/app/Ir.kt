package com.kumanda.app

import android.content.Context
import android.hardware.ConsumerIrManager

enum class Proto(val label: String, val maxCmd: Int) {
    NEC("NEC", 255),
    SAMSUNG("Samsung32", 255),
    RC5("RC5", 127),
    SONY("Sony SIRC", 127)
}

object Ir {
    private var rc5Toggle = false

    private fun mgr(c: Context): ConsumerIrManager? =
        c.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager

    fun available(c: Context): Boolean = mgr(c)?.hasIrEmitter() == true

    private fun necLike(h1: Int, h2: Int, bytes: IntArray): IntArray {
        val p = ArrayList<Int>()
        p.add(h1)
        p.add(h2)
        for (b in bytes) {
            for (i in 0 until 8) {
                p.add(560)
                p.add(if (((b shr i) and 1) == 1) 1690 else 560)
            }
        }
        p.add(560)
        return p.toIntArray()
    }

    private fun rc5(addr: Int, cmd: Int): IntArray {
        rc5Toggle = !rc5Toggle
        val bits = ArrayList<Int>()
        bits.add(1)
        bits.add(if (cmd < 64) 1 else 0)
        bits.add(if (rc5Toggle) 1 else 0)
        for (i in 4 downTo 0) bits.add((addr shr i) and 1)
        for (i in 5 downTo 0) bits.add((cmd shr i) and 1)
        // true = taşıyıcı açık (mark). Bit 1 = boşluk+mark, bit 0 = mark+boşluk.
        val halves = ArrayList<Boolean>()
        for (b in bits) {
            if (b == 1) { halves.add(false); halves.add(true) } else { halves.add(true); halves.add(false) }
        }
        val runs = ArrayList<Int>()
        var cur = halves[0]
        var len = 1
        for (i in 1 until halves.size) {
            if (halves[i] == cur) {
                len++
            } else {
                runs.add(len * 889)
                cur = halves[i]
                len = 1
            }
        }
        runs.add(len * 889)
        var out: List<Int> = runs
        if (!halves[0]) out = out.subList(1, out.size)           // baştaki boşluğu at
        if (!halves[halves.size - 1]) out = out.subList(0, out.size - 1) // sondaki boşluğu at
        return out.toIntArray()
    }

    private fun sony(addr: Int, cmd: Int): IntArray {
        val frame = ArrayList<Int>()
        frame.add(2400)
        frame.add(600)
        for (i in 0 until 7) {
            frame.add(if (((cmd shr i) and 1) == 1) 1200 else 600)
            frame.add(600)
        }
        for (i in 0 until 5) {
            frame.add(if (((addr shr i) and 1) == 1) 1200 else 600)
            frame.add(600)
        }
        val total = frame.sum()
        frame[frame.size - 1] = 600 + (45000 - total).coerceAtLeast(0)
        val out = ArrayList<Int>()
        repeat(3) { out.addAll(frame) }
        out.removeAt(out.size - 1)
        return out.toIntArray()
    }

    fun encode(proto: Proto, addr: Int, cmd: Int): Pair<Int, IntArray> = when (proto) {
        Proto.NEC -> 38000 to necLike(9000, 4500,
            intArrayOf(addr and 0xFF, addr.inv() and 0xFF, cmd and 0xFF, cmd.inv() and 0xFF))
        Proto.SAMSUNG -> 38000 to necLike(4500, 4500,
            intArrayOf(addr and 0xFF, addr and 0xFF, cmd and 0xFF, cmd.inv() and 0xFF))
        Proto.RC5 -> 36000 to rc5(addr, cmd)
        Proto.SONY -> 40000 to sony(addr, cmd)
    }

    fun send(c: Context, proto: Proto, addr: Int, cmd: Int): Boolean {
        val m = mgr(c) ?: return false
        if (!m.hasIrEmitter()) return false
        return try {
            val (f, p) = encode(proto, addr, cmd)
            m.transmit(f, p)
            true
        } catch (e: Exception) {
            false
        }
    }
}
