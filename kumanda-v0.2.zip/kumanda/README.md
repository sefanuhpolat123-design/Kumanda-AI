# Kumanda v0.2 — profiller, kod arama, sesli komut

## APK
Zip'i GitHub reposuna yükle. `.github/workflows/zip-to-apk.yml` otomatik başlar; APK "Releases" sayfasında çıkar.
(Workflow dosyasını repoda `.github/workflows/zip-to-apk.yml` adıyla elle oluşturman gerekebilir.)

## İlk kullanım
1. **TV'ler** sekmesi → "Kod ara": aranan tuşu seç (Ses +), "Dene" ya da taramayı başlat. TV tepki verince duraklat, kaydet.
2. Sırayla diğer tuşları öğret (kayıtlı kod varsa "Dene" → "Çalışıyor ✔").
3. **Ses** sekmesi: aktif TV'nin kanal adlarını gir (show tv=7).
4. **Kumanda** sekmesi: "Başlat" → izin → "Hey kumanda beşi aç".

## Xiaomi/Redmi
Ayarlar > Uygulamalar > Kumanda > Otomatik başlat: açık, Pil tasarrufu: Kısıtlama yok.
