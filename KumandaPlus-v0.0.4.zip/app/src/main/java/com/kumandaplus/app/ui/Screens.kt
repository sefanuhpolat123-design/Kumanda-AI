package com.kumandaplus.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.kumandaplus.app.data.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KeyButton(key: RKey, learned: Boolean, modifier: Modifier, vm: MainVm, onLearn: (RKey) -> Unit) {
    val color = if (learned) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.surfaceVariant
    Surface(
        shape = RoundedCornerShape(16.dp), color = color,
        modifier = modifier.height(56.dp).combinedClickable(
            onClick = { vm.press(key) }, onLongClick = { onLearn(key) })
    ) { Box(contentAlignment = Alignment.Center) { Text(key.label, style = MaterialTheme.typography.titleMedium) } }
}

@Composable
fun RemoteScreen(vm: MainVm) {
    val tv by vm.current.collectAsState()
    val keys by vm.keys.collectAsState()
    val scan by vm.scan.collectAsState()
    val t = tv
    if (t == null) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Önce Televizyonlar sekmesinden bir televizyon ekle.")
        }
        return
    }
    val have = keys.map { it.keyName }.toSet()
    @Composable fun RowScope.k(key: RKey) =
        KeyButton(key, key.name in have, Modifier.weight(1f), vm) { vm.startScan(it) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(t.name, style = MaterialTheme.typography.headlineSmall)
        if (!vm.hasIr) Text("Bu cihazda IR vericisi yok; sinyal gönderilemez.", color = MaterialTheme.colorScheme.error)
        Text("Koyu renkli tuşların kodu kayıtlı. Boş tuşa basılı tutarak TV'ye öğret.",
            style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { k(RKey.POWER); k(RKey.POWER_ON); k(RKey.POWER_OFF) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { k(RKey.VOL_DOWN); k(RKey.MUTE); k(RKey.VOL_UP) }
        listOf(listOf(RKey.D1, RKey.D2, RKey.D3), listOf(RKey.D4, RKey.D5, RKey.D6), listOf(RKey.D7, RKey.D8, RKey.D9))
            .forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { row.forEach { k(it) } } }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Spacer(Modifier.weight(1f)); k(RKey.D0); Spacer(Modifier.weight(1f)) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { k(RKey.HOME); k(RKey.YOUTUBE) }
    }
    scan?.let { s ->
        AlertDialog(
            onDismissRequest = { vm.scanStop() },
            title = { Text("${s.key.label} tuşu aranıyor") },
            text = {
                Text("Kod ${s.code}/255 gönderildi. Televizyon istenen tepkiyi verdiği anda \"Oldu!\"ya bas. " +
                    "Aramada başka tuşlar da tetiklenebilir.")
            },
            confirmButton = { Button(onClick = { vm.scanFound() }) { Text("Oldu!") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { vm.scanBack() }) { Text("Geri") }
                    TextButton(onClick = { vm.scanStop() }) { Text("Durdur") }
                }
            }
        )
    }
}

@Composable
fun TvsScreen(vm: MainVm) {
    val tvs by vm.tvs.collectAsState()
    val cur by vm.current.collectAsState()
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("Toshiba") }
    var addr by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<TvEntity?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Yeni televizyon ekle", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(name, { name = it }, label = { Text("Televizyon adı") }, singleLine = true,
            modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(brand == "Toshiba", { brand = "Toshiba" }, label = { Text("Toshiba (hazır profil)") })
            FilterChip(brand != "Toshiba", { brand = "Diğer" }, label = { Text("Diğer (NEC)") })
        }
        if (brand != "Toshiba") {
            OutlinedTextField(addr, { addr = it.filter(Char::isDigit) }, label = { Text("NEC cihaz adresi (0-255)") },
                singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth())
        }
        val address = if (brand == "Toshiba") 64 else addr.toIntOrNull()
        Button(enabled = name.isNotBlank() && address != null && address in 0..255, onClick = {
            vm.addTv(name, brand, address!!); name = ""; addr = ""
        }) { Text("Ekle") }
        Divider()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tvs, key = { it.id }) { tv ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tv.name, style = MaterialTheme.typography.titleMedium)
                            Text("${tv.brand} · adres ${tv.address}" + if (tv.id == cur?.id) " · seçili" else "",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.select(tv) }) { Text("Seç") }
                        TextButton(onClick = { toDelete = tv }) { Text("Sil") }
                    }
                }
            }
        }
    }
    toDelete?.let { tv ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text("${tv.name} silinsin mi?") },
            text = { Text("Tuş kodları ve kanal listesi de silinir.") },
            confirmButton = { Button(onClick = { vm.deleteTv(tv); toDelete = null }) { Text("Sil") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Vazgeç") } })
    }
}

@Composable
fun ChannelsScreen(vm: MainVm) {
    val chs by vm.channels.collectAsState()
    val tv by vm.current.collectAsState()
    var num by remember { mutableStateOf("") }
    var nm by remember { mutableStateOf("") }
    if (tv == null) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text("Önce bir televizyon ekle.") }
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${tv?.name} kanalları", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(num, { num = it.filter(Char::isDigit).take(4) }, label = { Text("No") }, singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(90.dp))
            OutlinedTextField(nm, { nm = it }, label = { Text("Kanal adı") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Button(enabled = num.isNotEmpty() && nm.isNotBlank(), onClick = {
            vm.addChannel(num.toInt(), nm); num = ""; nm = ""
        }) { Text("Kanal ekle") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(chs, key = { it.id }) { c ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${c.number}  ${c.name}", Modifier.weight(1f))
                        TextButton(onClick = { vm.tune(c) }) { Text("Aç") }
                        TextButton(onClick = { vm.deleteChannel(c) }) { Text("Sil") }
                    }
                }
            }
        }
    }
}
